# CAP RÉUSSITE TCHAD

*Comprendre simplement. Apprendre durablement. Réussir avec confiance.*

Plateforme éducative pour les élèves du secondaire au Tchad (Next.js, TypeScript, Tailwind, Supabase, Vercel).

## État d'avancement
- Phases 1, 3, 4, 5 et 6 (code, non testé) : connexion, tableau de bord, catalogue, leçons, progression, administration des élèves.
- **Non encore testé** : le code n'a pas été compilé ni exécuté. Lancez `npm run typecheck` et `npm run build` et corrigez les erreurs éventuelles.

## Lancer en local
1. `npm install`
2. Copier `.env.example` vers `.env.local` et remplir les valeurs Supabase.
3. `npm run dev` puis ouvrir http://localhost:3000

## Base de données (Supabase)
Exécuter dans l'ordre, dans SQL Editor :
1. `supabase/migrations/0001_schema_et_securite.sql`
2. `supabase/migrations/0002_referentiel_provisoire.sql`
3. `supabase/migrations/0003_journal_audit.sql`
4. `supabase/migrations/0004_favoris_ressources.sql`
5. `supabase/migrations/0005_quiz_et_evaluations.sql`

(Optionnel) `docs/exemple_quiz_demo.sql` crée un quiz FICTIF pour tester le moteur ; à supprimer ensuite.

Puis lancer `tests/rls_tests.sql` (annulé automatiquement) : il doit afficher « TOUS LES TESTS REUSSIS ».
Dans Supabase > Authentication > URL Configuration, ajouter l'adresse du site et `/auth/callback` aux « Redirect URLs » (pour le lien de réinitialisation).

## Premier administrateur
1. Créer un compte via Supabase > Authentication > Users.
2. Dans SQL Editor : `update public.profiles set role = 'admin', is_active = true where id = '<UUID du compte>';`

Nul ne peut se donner ce rôle depuis l'application : un déclencheur SQL bloque tout changement de rôle par un non-administrateur.

## Sécurité
- Nouveaux comptes : rôle `student`, **inactifs** jusqu'à activation par un administrateur.
- RLS activé sur toutes les tables ; un élève ne voit que sa propre progression.
- `SUPABASE_SERVICE_ROLE_KEY` et `AI_API_KEY` : serveur uniquement, jamais dans le navigateur.
- Les politiques RLS n'ont pas encore été testées sur une vraie base.

## Contenus scolaires
Classes et matières sont **provisoires** (`is_provisional`). Aucun programme officiel n'est encore vérifié.

## Administration (/admin)
Réservée aux comptes `admin` actifs. Gère : élèves (activation, classe), cours (classes, matières, chapitres, leçons, publication), documents, quiz et examens, suivi, rôles.
- Rédaction d'une leçon : sections `## type | Titre` (types : objectifs, definition, formule, exemple, erreur, resume, texte).
- Téléversement : PDF, PNG, JPEG, Word, PowerPoint, 10 Mo max. Le type est vérifié d'après l'indication du navigateur ; **aucun antivirus n'est appliqué** : ne publiez que des fichiers de confiance.
- Chaque action admin est re-vérifiée côté serveur (`requireAdmin`) et par la RLS de la base.
