-- Tests de sécurité (RLS). À exécuter dans Supabase > SQL Editor APRÈS les migrations 0001 à 0005.
-- Tout est annulé à la fin (rollback). Une erreur « ECHEC : ... » signifie qu'une règle est cassée.
-- Résultat attendu : le script se termine sans erreur et affiche « TOUS LES TESTS REUSSIS ».
begin;

insert into auth.users (id, email) values
  ('00000000-0000-0000-0000-0000000000a1', 'admin@test.invalid'),
  ('00000000-0000-0000-0000-0000000000b1', 'eleve1@test.invalid'),
  ('00000000-0000-0000-0000-0000000000b2', 'eleve2@test.invalid'),
  ('00000000-0000-0000-0000-0000000000c1', 'inactif@test.invalid');
update public.profiles set role = 'admin', is_active = true where id = '00000000-0000-0000-0000-0000000000a1';
update public.profiles set is_active = true where id in ('00000000-0000-0000-0000-0000000000b1','00000000-0000-0000-0000-0000000000b2');
insert into public.classes (id, name, level) values ('00000000-0000-0000-0000-00000000c0c0', 'Classe test', 'Test');
insert into public.subjects (id, class_id, name) values ('00000000-0000-0000-0000-00000000d0d0', '00000000-0000-0000-0000-00000000c0c0', 'Matière test');
insert into public.chapters (id, subject_id, title, is_published) values ('00000000-0000-0000-0000-00000000e0e0', '00000000-0000-0000-0000-00000000d0d0', 'Chapitre test', true);
insert into public.lessons (id, chapter_id, title, is_published) values ('00000000-0000-0000-0000-00000000f0f0', '00000000-0000-0000-0000-00000000e0e0', 'Leçon test', true);
insert into public.student_progress (student_id, lesson_id, completed) values ('00000000-0000-0000-0000-0000000000b2', '00000000-0000-0000-0000-00000000f0f0', true);
insert into public.student_favorites (student_id, lesson_id) values ('00000000-0000-0000-0000-0000000000b2', '00000000-0000-0000-0000-00000000f0f0');

update public.profiles set class_id = '00000000-0000-0000-0000-00000000c0c0' where id in ('00000000-0000-0000-0000-0000000000b1','00000000-0000-0000-0000-0000000000b2');
insert into public.quizzes (id, class_id, kind, title, is_published) values ('00000000-0000-0000-0000-000000a0a001', '00000000-0000-0000-0000-00000000c0c0', 'exercise', 'Quiz test', true);
insert into public.quiz_questions (id, quiz_id, position, type, prompt) values ('00000000-0000-0000-0000-000000a0a002', '00000000-0000-0000-0000-000000a0a001', 1, 'mcq', 'Q test');
insert into public.quiz_choices (id, question_id, label) values ('00000000-0000-0000-0000-000000a0a003', '00000000-0000-0000-0000-000000a0a002', 'bonne'), ('00000000-0000-0000-0000-000000a0a004', '00000000-0000-0000-0000-000000a0a002', 'mauvaise');
insert into public.question_keys (question_id, correct_choice_ids, explanation) values ('00000000-0000-0000-0000-000000a0a002', array['00000000-0000-0000-0000-000000a0a003'::uuid], 'Explication test');
insert into public.quiz_attempts (id, quiz_id, student_id) values ('00000000-0000-0000-0000-000000a0a005', '00000000-0000-0000-0000-000000a0a001', '00000000-0000-0000-0000-0000000000b2');

-- ===== Connecté en tant qu'élève 1 =====
set local role authenticated;
select set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-0000000000b1","role":"authenticated"}', true);

do $$ begin
  if (select count(*) from public.profiles) <> 1 then raise exception 'ECHEC : un élève voit d''autres profils'; end if;
  if (select count(*) from public.student_progress) <> 0 then raise exception 'ECHEC : un élève voit la progression d''un autre'; end if;
  if (select count(*) from public.student_favorites) <> 0 then raise exception 'ECHEC : un élève voit les favoris d''un autre'; end if;
  if (select count(*) from public.lessons) <> 1 then raise exception 'ECHEC : un élève actif ne voit pas les leçons publiées'; end if;
end $$;

do $$ begin
  begin
    update public.profiles set role = 'admin' where id = '00000000-0000-0000-0000-0000000000b1';
    raise exception 'ECHEC : un élève a pu se donner le rôle admin';
  exception when others then
    if sqlerrm like 'ECHEC%' then raise; end if;
  end;
  begin
    insert into public.subjects (class_id, name) values ('00000000-0000-0000-0000-00000000c0c0', 'Intrus');
    raise exception 'ECHEC : un élève a pu créer une matière';
  exception when others then
    if sqlerrm like 'ECHEC%' then raise; end if;
  end;
  begin
    insert into public.student_progress (student_id, lesson_id) values ('00000000-0000-0000-0000-0000000000b2', '00000000-0000-0000-0000-00000000f0f0');
    raise exception 'ECHEC : un élève a pu écrire la progression d''un autre';
  exception when others then
    if sqlerrm like 'ECHEC%' then raise; end if;
  end;
  if (select count(*) from public.audit_logs) <> 0 then raise exception 'ECHEC : un élève lit le journal d''audit'; end if;
  begin
    insert into public.lesson_resources (lesson_id, title, file_path) values ('00000000-0000-0000-0000-00000000f0f0', 'Intrus', 'x/y.pdf');
    raise exception 'ECHEC : un élève a pu ajouter un document';
  exception when others then if sqlerrm like 'ECHEC%' then raise; end if; end;
  begin
    insert into public.quizzes (class_id, kind, title) values ('00000000-0000-0000-0000-00000000c0c0', 'exercise', 'Intrus');
    raise exception 'ECHEC : un élève a pu créer une évaluation';
  exception when others then if sqlerrm like 'ECHEC%' then raise; end if; end;
end $$;

do $$ declare v uuid; begin
  if (select count(*) from public.question_keys) <> 0 then raise exception 'ECHEC : un élève lit les bonnes réponses'; end if;
  if (select count(*) from public.quiz_attempts) <> 0 then raise exception 'ECHEC : un élève voit les tentatives d''un autre'; end if;
  begin
    insert into public.quiz_attempts (quiz_id, student_id) values ('00000000-0000-0000-0000-000000a0a001', '00000000-0000-0000-0000-0000000000b1');
    raise exception 'ECHEC : un élève a pu créer une tentative sans passer par la fonction';
  exception when others then if sqlerrm like 'ECHEC%' then raise; end if; end;
  begin
    perform public.submit_attempt('00000000-0000-0000-0000-000000a0a005', '{}'::jsonb);
    raise exception 'ECHEC : un élève a pu soumettre la tentative d''un autre';
  exception when others then if sqlerrm like 'ECHEC%' then raise; end if; end;
  v := public.start_attempt('00000000-0000-0000-0000-000000a0a001');
  perform public.submit_attempt(v, '{"00000000-0000-0000-0000-000000a0a002": ["00000000-0000-0000-0000-000000a0a003"]}'::jsonb);
  if (select score from public.quiz_attempts where id = v) <> 1 then raise exception 'ECHEC : score correct non calculé'; end if;
  v := public.start_attempt('00000000-0000-0000-0000-000000a0a001');
  perform public.submit_attempt(v, '{"00000000-0000-0000-0000-000000a0a002": "00000000-0000-0000-0000-000000a0a004"}'::jsonb);
  if (select score from public.quiz_attempts where id = v) <> 0 then raise exception 'ECHEC : mauvaise réponse notée juste'; end if;
end $$;

-- ===== Compte inactif =====
reset role; set local role authenticated;
select set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-0000000000c1","role":"authenticated"}', true);
do $$ begin
  if (select count(*) from public.classes) <> 0 or (select count(*) from public.lessons) <> 0 then
    raise exception 'ECHEC : un compte inactif accède aux contenus';
  end if;
end $$;

-- ===== Administrateur =====
reset role; set local role authenticated;
select set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-0000000000a1","role":"authenticated"}', true);
do $$ begin
  if (select count(*) from public.profiles) < 4 then raise exception 'ECHEC : l''admin ne voit pas tous les profils'; end if;
  update public.profiles set class_id = '00000000-0000-0000-0000-00000000c0c0' where id = '00000000-0000-0000-0000-0000000000b1';
  if (select count(*) from public.audit_logs where target_id = '00000000-0000-0000-0000-0000000000b1') < 1 then
    raise exception 'ECHEC : changement admin non journalisé';
  end if;
  insert into public.subjects (class_id, name) values ('00000000-0000-0000-0000-00000000c0c0', 'Matière admin');
  insert into public.quizzes (class_id, kind, title) values ('00000000-0000-0000-0000-00000000c0c0', 'exercise', 'Quiz admin');
  insert into public.lesson_resources (lesson_id, title, file_path) values ('00000000-0000-0000-0000-00000000f0f0', 'Doc admin', 'x/y.pdf');
  update public.profiles set role = 'admin' where id = '00000000-0000-0000-0000-0000000000b2';
  if (select role from public.profiles where id = '00000000-0000-0000-0000-0000000000b2') <> 'admin' then raise exception 'ECHEC : promotion par un admin impossible'; end if;
end $$;

reset role;
select 'TOUS LES TESTS REUSSIS' as resultat;
rollback;
