export default function Accueil() {
  return (
    <main className="mx-auto flex min-h-screen max-w-3xl flex-col justify-center gap-6 px-6 py-16">
      <h1 className="text-4xl font-bold tracking-tight text-marine-900 sm:text-5xl">
        CAP RÉUSSITE TCHAD
      </h1>
      <p className="text-xl text-marine-800">
        Comprendre simplement. Apprendre durablement. Réussir avec confiance.
      </p>
      <p className="max-w-prose text-slate-700">
        Les fondations techniques du projet sont en place. L'interface complète
        (accueil, connexion, cours, quiz, tuteur IA) arrive aux phases suivantes.
      </p>
    </main>
  );
}
