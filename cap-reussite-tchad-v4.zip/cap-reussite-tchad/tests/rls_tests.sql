-- Tests de sécurité (RLS). À exécuter dans Supabase > SQL Editor APRÈS les migrations 0001 à 0004.
-- Tout est annulé à la fin (rollback). Une erreur « ECHEC : ... » signifie qu'une règle est cassée.
-- Résultat attendu : le script se termine sans erreur et affiche « TOUS LES TESTS REUSSIS ».
begin;

insert into auth.users (id, email) values
  ('00000000-0000-0000-0000-0000000000a1', 'admin@test.invalid'),
  ('00000000-0000-0000-0000-0000000000b1', 'eleve1@test.invalid'),
  ('00000000-0000-0000-0000-0000000000b2', 'eleve2@test.invalid'),
  ('00000000-0000-0000-0000-0000000000c1', 'inactif@test.invalid');
update public.profiles set role = 'admin', is_active = true where id = '00000000-0000-0000-0000-0000000000a1';
update public.profiles set is_active = true where id in ('00000000-0000-0000-0000-0000000000b1','00000000-0000-0000-0000-0000000000b2');
insert into public.classes (id, name, level) values ('00000000-0000-0000-0000-00000000c0c0', 'Classe test', 'Test');
insert into public.subjects (id, class_id, name) values ('00000000-0000-0000-0000-00000000d0d0', '00000000-0000-0000-0000-00000000c0c0', 'Matière test');
insert into public.chapters (id, subject_id, title, is_published) values ('00000000-0000-0000-0000-00000000e0e0', '00000000-0000-0000-0000-00000000d0d0', 'Chapitre test', true);
insert into public.lessons (id, chapter_id, title, is_published) values ('00000000-0000-0000-0000-00000000f0f0', '00000000-0000-0000-0000-00000000e0e0', 'Leçon test', true);
insert into public.student_progress (student_id, lesson_id, completed) values ('00000000-0000-0000-0000-0000000000b2', '00000000-0000-0000-0000-00000000f0f0', true);
insert into public.student_favorites (student_id, lesson_id) values ('00000000-0000-0000-0000-0000000000b2', '00000000-0000-0000-0000-00000000f0f0');

-- ===== Connecté en tant qu'élève 1 =====
set local role authenticated;
select set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-0000000000b1","role":"authenticated"}', true);

do $$ begin
  if (select count(*) from public.profiles) <> 1 then raise exception 'ECHEC : un élève voit d''autres profils'; end if;
  if (select count(*) from public.student_progress) <> 0 then raise exception 'ECHEC : un élève voit la progression d''un autre'; end if;
  if (select count(*) from public.student_favorites) <> 0 then raise exception 'ECHEC : un élève voit les favoris d''un autre'; end if;
  if (select count(*) from public.lessons) <> 1 then raise exception 'ECHEC : un élève actif ne voit pas les leçons publiées'; end if;
end $$;

do $$ begin
  begin
    update public.profiles set role = 'admin' where id = '00000000-0000-0000-0000-0000000000b1';
    raise exception 'ECHEC : un élève a pu se donner le rôle admin';
  exception when others then
    if sqlerrm like 'ECHEC%' then raise; end if;
  end;
  begin
    insert into public.subjects (class_id, name) values ('00000000-0000-0000-0000-00000000c0c0', 'Intrus');
    raise exception 'ECHEC : un élève a pu créer une matière';
  exception when others then
    if sqlerrm like 'ECHEC%' then raise; end if;
  end;
  begin
    insert into public.student_progress (student_id, lesson_id) values ('00000000-0000-0000-0000-0000000000b2', '00000000-0000-0000-0000-00000000f0f0');
    raise exception 'ECHEC : un élève a pu écrire la progression d''un autre';
  exception when others then
    if sqlerrm like 'ECHEC%' then raise; end if;
  end;
  if (select count(*) from public.audit_logs) <> 0 then raise exception 'ECHEC : un élève lit le journal d''audit'; end if;
end $$;

-- ===== Compte inactif =====
reset role; set local role authenticated;
select set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-0000000000c1","role":"authenticated"}', true);
do $$ begin
  if (select count(*) from public.classes) <> 0 or (select count(*) from public.lessons) <> 0 then
    raise exception 'ECHEC : un compte inactif accède aux contenus';
  end if;
end $$;

-- ===== Administrateur =====
reset role; set local role authenticated;
select set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-0000000000a1","role":"authenticated"}', true);
do $$ begin
  if (select count(*) from public.profiles) < 4 then raise exception 'ECHEC : l''admin ne voit pas tous les profils'; end if;
  update public.profiles set class_id = '00000000-0000-0000-0000-00000000c0c0' where id = '00000000-0000-0000-0000-0000000000b1';
  if (select count(*) from public.audit_logs where target_id = '00000000-0000-0000-0000-0000000000b1') < 1 then
    raise exception 'ECHEC : changement admin non journalisé';
  end if;
end $$;

reset role;
select 'TOUS LES TESTS REUSSIS' as resultat;
rollback;
