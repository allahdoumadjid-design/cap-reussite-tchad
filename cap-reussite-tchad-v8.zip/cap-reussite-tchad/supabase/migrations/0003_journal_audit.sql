-- Migration 0003 : journal d'audit des changements sensibles sur les profils.
create table public.audit_logs (
  id bigint generated always as identity primary key,
  actor_id uuid,                          -- auth.uid() au moment de l'action (null si action via SQL Editor)
  action text not null,
  target_id uuid,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index on public.audit_logs (created_at desc);
alter table public.audit_logs enable row level security;
-- Lecture réservée aux administrateurs. Aucune politique d'écriture : seul le déclencheur ci-dessous écrit.
create policy audit_admin_read on public.audit_logs for select using (public.is_admin());

create or replace function public.log_profile_changes() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.role is distinct from old.role or new.is_active is distinct from old.is_active
     or new.class_id is distinct from old.class_id then
    insert into audit_logs (actor_id, action, target_id, details) values (
      auth.uid(), 'profile_update', new.id,
      jsonb_build_object('role', jsonb_build_array(old.role, new.role),
                         'is_active', jsonb_build_array(old.is_active, new.is_active),
                         'class_id', jsonb_build_array(old.class_id, new.class_id)));
  end if;
  return new;
end; $$;

create trigger profiles_audit after update on public.profiles
  for each row execute function public.log_profile_changes();
