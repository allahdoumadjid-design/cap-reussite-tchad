-- CAP RÉUSSITE TCHAD — Migration 0001 : schéma de base + sécurité (RLS)
-- À exécuter en premier. Supabase > SQL Editor, ou `supabase db push`.

create type public.user_role as enum ('student', 'admin');

create table public.schools (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  created_at timestamptz not null default now()
);

create table public.classes (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,              -- ex. « Terminale C »
  level text not null,                    -- ex. « Lycée »
  sort_order int not null default 0,
  is_provisional boolean not null default true  -- structure à valider avec les sources officielles
);

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null check (char_length(display_name) between 2 and 80),
  role public.user_role not null default 'student',
  is_active boolean not null default false,     -- activé par un administrateur
  class_id uuid references public.classes(id) on delete set null,
  school_id uuid references public.schools(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.subjects (
  id uuid primary key default gen_random_uuid(),
  class_id uuid not null references public.classes(id) on delete cascade,
  name text not null,
  sort_order int not null default 0,
  unique (class_id, name)
);

create table public.chapters (
  id uuid primary key default gen_random_uuid(),
  subject_id uuid not null references public.subjects(id) on delete cascade,
  title text not null,
  sort_order int not null default 0,
  is_published boolean not null default false
);

create table public.lessons (
  id uuid primary key default gen_random_uuid(),
  chapter_id uuid not null references public.chapters(id) on delete cascade,
  title text not null,
  content jsonb not null default '{}'::jsonb,   -- sections structurées (objectifs, exemples, résumé…)
  sort_order int not null default 0,
  is_published boolean not null default false,
  updated_at timestamptz not null default now()
);

create table public.student_progress (
  student_id uuid not null references public.profiles(id) on delete cascade,
  lesson_id uuid not null references public.lessons(id) on delete cascade,
  completed boolean not null default false,
  last_viewed_at timestamptz not null default now(),
  primary key (student_id, lesson_id)
);

create index on public.subjects (class_id);
create index on public.chapters (subject_id);
create index on public.lessons (chapter_id);
create index on public.student_progress (student_id);

-- Fonctions d'aide (security definer : évite la récursion des politiques RLS)
create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from profiles where id = auth.uid() and role = 'admin' and is_active);
$$;

create or replace function public.is_active_user() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from profiles where id = auth.uid() and is_active);
$$;

-- À l'inscription : profil créé TOUJOURS en rôle « student » et inactif.
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into profiles (id, display_name)
  values (new.id, coalesce(nullif(trim(new.raw_user_meta_data->>'display_name'), ''), 'Élève'));
  return new;
end; $$;

create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- Un non-administrateur ne peut pas modifier son rôle, son statut, sa classe ni son école.
create or replace function public.protect_profile_fields() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is not null and not public.is_admin() then  -- auth.uid() null = SQL Editor / service role (de confiance)
    if new.role is distinct from old.role or new.is_active is distinct from old.is_active
       or new.class_id is distinct from old.class_id or new.school_id is distinct from old.school_id then
      raise exception 'Modification non autorisée';
    end if;
  end if;
  new.updated_at = now();
  return new;
end; $$;

create trigger profiles_protect before update on public.profiles
  for each row execute function public.protect_profile_fields();

-- Row Level Security
alter table public.schools          enable row level security;
alter table public.classes          enable row level security;
alter table public.profiles         enable row level security;
alter table public.subjects         enable row level security;
alter table public.chapters         enable row level security;
alter table public.lessons          enable row level security;
alter table public.student_progress enable row level security;

-- Profils : chacun lit/modifie le sien ; l'administrateur gère tout.
create policy profiles_select on public.profiles for select using (id = auth.uid() or public.is_admin());
create policy profiles_update on public.profiles for update using (id = auth.uid() or public.is_admin())
  with check (id = auth.uid() or public.is_admin());
create policy profiles_admin_delete on public.profiles for delete using (public.is_admin());

-- Référentiel et contenus : lecture réservée aux comptes actifs (contenus publiés) ; écriture admin.
create policy schools_read  on public.schools  for select using (public.is_active_user());
create policy classes_read  on public.classes  for select using (public.is_active_user());
create policy subjects_read on public.subjects for select using (public.is_active_user());
create policy chapters_read on public.chapters for select using (public.is_active_user() and (is_published or public.is_admin()));
create policy lessons_read  on public.lessons  for select using (public.is_active_user() and (is_published or public.is_admin()));

create policy schools_admin  on public.schools  for all using (public.is_admin()) with check (public.is_admin());
create policy classes_admin  on public.classes  for all using (public.is_admin()) with check (public.is_admin());
create policy subjects_admin on public.subjects for all using (public.is_admin()) with check (public.is_admin());
create policy chapters_admin on public.chapters for all using (public.is_admin()) with check (public.is_admin());
create policy lessons_admin  on public.lessons  for all using (public.is_admin()) with check (public.is_admin());

-- Progression : strictement privée à l'élève ; lecture par l'administrateur.
create policy progress_own on public.student_progress for all
  using (student_id = auth.uid() and public.is_active_user())
  with check (student_id = auth.uid() and public.is_active_user());
create policy progress_admin_read on public.student_progress for select using (public.is_admin());
