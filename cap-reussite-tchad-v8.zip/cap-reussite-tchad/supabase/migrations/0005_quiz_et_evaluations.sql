-- Migration 0005 : exercices, quiz, examens blancs. Les scores sont calculés EN BASE (fonctions security definer).
-- Les bonnes réponses sont dans question_keys, illisible par les élèves (admin seulement).

-- Correctif si 0001 ancienne version a déjà été exécutée (sans effet sinon) :
create or replace function public.protect_profile_fields() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is not null and not public.is_admin() then
    if new.role is distinct from old.role or new.is_active is distinct from old.is_active
       or new.class_id is distinct from old.class_id or new.school_id is distinct from old.school_id then
      raise exception 'Modification non autorisée';
    end if;
  end if;
  new.updated_at = now();
  return new;
end; $$;

create type public.quiz_kind as enum ('exercise','lesson_quiz','chapter_quiz','subject_eval','bac_blanc','bac_topic');
create type public.question_type as enum ('mcq','numeric','open');

create table public.quizzes (
  id uuid primary key default gen_random_uuid(),
  class_id uuid not null references public.classes(id) on delete cascade,
  subject_id uuid references public.subjects(id) on delete set null,
  lesson_id uuid references public.lessons(id) on delete set null,
  kind public.quiz_kind not null,
  title text not null,
  time_limit_minutes int check (time_limit_minutes is null or time_limit_minutes between 1 and 360),
  is_official boolean not null default false,   -- ne mettre true que si l'authenticité du sujet est vérifiée
  source_note text,
  is_published boolean not null default false,
  created_at timestamptz not null default now()
);
create table public.quiz_questions (
  id uuid primary key default gen_random_uuid(),
  quiz_id uuid not null references public.quizzes(id) on delete cascade,
  position int not null default 0,
  type public.question_type not null,
  multiple boolean not null default false,       -- QCM à réponses multiples
  prompt text not null,
  topic text,                                    -- notion évaluée (sert aux recommandations de révision)
  points numeric not null default 1 check (points > 0)
);
create table public.quiz_choices (
  id uuid primary key default gen_random_uuid(),
  question_id uuid not null references public.quiz_questions(id) on delete cascade,
  label text not null,
  position int not null default 0
);
create table public.question_keys (
  question_id uuid primary key references public.quiz_questions(id) on delete cascade,
  correct_choice_ids uuid[] not null default '{}',
  numeric_answer numeric,
  numeric_tolerance numeric not null default 0 check (numeric_tolerance >= 0),
  keywords text[] not null default '{}',         -- question ouverte : mots-clés attendus (évaluation approximative)
  explanation text not null,
  common_mistake text
);
create table public.quiz_attempts (
  id uuid primary key default gen_random_uuid(),
  quiz_id uuid not null references public.quizzes(id) on delete cascade,
  student_id uuid not null references public.profiles(id) on delete cascade,
  status text not null default 'in_progress' check (status in ('in_progress','submitted')),
  started_at timestamptz not null default now(),
  submitted_at timestamptz,
  late boolean not null default false,
  score numeric, max_score numeric
);
create table public.quiz_answers (
  attempt_id uuid not null references public.quiz_attempts(id) on delete cascade,
  question_id uuid not null references public.quiz_questions(id) on delete cascade,
  answer jsonb,
  is_correct boolean not null,
  points_awarded numeric not null,
  primary key (attempt_id, question_id)
);
create index on public.quizzes (class_id, kind);
create index on public.quiz_questions (quiz_id);
create index on public.quiz_choices (question_id);
create index on public.quiz_attempts (student_id, quiz_id);
create index on public.quiz_answers (question_id);

create or replace function public.my_class_id() returns uuid
language sql stable security definer set search_path = public as $$
  select class_id from profiles where id = auth.uid();
$$;

alter table public.quizzes        enable row level security;
alter table public.quiz_questions enable row level security;
alter table public.quiz_choices   enable row level security;
alter table public.question_keys  enable row level security;
alter table public.quiz_attempts  enable row level security;
alter table public.quiz_answers   enable row level security;

create policy quizzes_read on public.quizzes for select
  using (public.is_active_user() and (public.is_admin() or (is_published and class_id = public.my_class_id())));
create policy questions_read on public.quiz_questions for select
  using (exists (select 1 from public.quizzes z where z.id = quiz_id));
create policy choices_read on public.quiz_choices for select
  using (exists (select 1 from public.quiz_questions q where q.id = question_id));
create policy quizzes_admin   on public.quizzes        for all using (public.is_admin()) with check (public.is_admin());
create policy questions_admin on public.quiz_questions for all using (public.is_admin()) with check (public.is_admin());
create policy choices_admin   on public.quiz_choices   for all using (public.is_admin()) with check (public.is_admin());
create policy keys_admin      on public.question_keys  for all using (public.is_admin()) with check (public.is_admin());
-- Tentatives et réponses : lecture seule pour l'élève ; écriture uniquement via les fonctions ci-dessous.
create policy attempts_read on public.quiz_attempts for select using (student_id = auth.uid() or public.is_admin());
create policy answers_read  on public.quiz_answers  for select
  using (exists (select 1 from public.quiz_attempts a where a.id = attempt_id and (a.student_id = auth.uid() or public.is_admin())));

create or replace function public.norm_text(t text) returns text language sql immutable as $$
  select lower(translate(coalesce(t,''), 'ÀÂÄÉÈÊËÎÏÔÖÙÛÜÇàâäéèêëîïôöùûüç', 'AAAEEEEIIOOUUUCaaaeeeeiioouuuc'));
$$;

create or replace function public.start_attempt(p_quiz_id uuid) returns uuid
language plpgsql security definer set search_path = public as $$
declare v_id uuid;
begin
  if not public.is_active_user() then raise exception 'Compte inactif'; end if;
  if not exists (select 1 from quizzes where id = p_quiz_id and is_published
                 and (class_id = public.my_class_id() or public.is_admin())) then
    raise exception 'Évaluation introuvable';
  end if;
  insert into quiz_attempts (quiz_id, student_id) values (p_quiz_id, auth.uid()) returning id into v_id;
  return v_id;
end $$;

create or replace function public.submit_attempt(p_attempt_id uuid, p_answers jsonb) returns void
language plpgsql security definer set search_path = public as $$
declare
  a quiz_attempts; q record; k question_keys; v jsonb;
  ok boolean; frac numeric; pts numeric; total numeric := 0; maxi numeric := 0;
  lim int; ids uuid[]; good uuid[]; num numeric; hit int; kw text; txt text;
begin
  select * into a from quiz_attempts where id = p_attempt_id and student_id = auth.uid() for update;
  if not found then raise exception 'Tentative introuvable'; end if;
  if a.status <> 'in_progress' then raise exception 'Tentative déjà soumise'; end if;
  select time_limit_minutes into lim from quizzes where id = a.quiz_id;
  for q in select * from quiz_questions where quiz_id = a.quiz_id loop
    select * into k from question_keys where question_id = q.id;
    v := p_answers -> q.id::text;
    ok := false; frac := 0;
    if v is not null and jsonb_typeof(v) <> 'null' then
      if q.type = 'mcq' then
        select coalesce(array_agg(u order by u), '{}') into ids from (
          select case when x ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' then x::uuid end as u
          from jsonb_array_elements_text(case when jsonb_typeof(v) = 'array' then v else jsonb_build_array(v) end) x) s
        where u is not null;
        select coalesce(array_agg(c order by c), '{}') into good from unnest(coalesce(k.correct_choice_ids, '{}')) c;
        ok := cardinality(good) > 0 and ids = good;
        frac := case when ok then 1 else 0 end;
      elsif q.type = 'numeric' then
        begin num := replace(trim(v #>> '{}'), ',', '.')::numeric; exception when others then num := null; end;
        ok := num is not null and k.numeric_answer is not null and abs(num - k.numeric_answer) <= k.numeric_tolerance;
        frac := case when ok then 1 else 0 end;
      else
        txt := norm_text(left(v #>> '{}', 2000)); hit := 0;
        if cardinality(coalesce(k.keywords, '{}')) > 0 then
          foreach kw in array k.keywords loop
            if position(norm_text(kw) in txt) > 0 then hit := hit + 1; end if;
          end loop;
          frac := hit::numeric / cardinality(k.keywords);
          ok := frac >= 0.6;
        end if;
      end if;
    end if;
    pts := round(q.points * frac, 2);
    insert into quiz_answers (attempt_id, question_id, answer, is_correct, points_awarded) values (a.id, q.id, v, ok, pts);
    total := total + pts; maxi := maxi + q.points;
  end loop;
  update quiz_attempts set status = 'submitted', submitted_at = now(), score = total, max_score = maxi,
    late = (lim is not null and now() > started_at + make_interval(mins => lim) + interval '60 seconds')
  where id = a.id;
end $$;

create or replace function public.attempt_review(p_attempt_id uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare a quiz_attempts;
begin
  select * into a from quiz_attempts where id = p_attempt_id and (student_id = auth.uid() or public.is_admin());
  if not found then raise exception 'Tentative introuvable'; end if;
  if a.status <> 'submitted' then raise exception 'Tentative non terminée'; end if;
  return jsonb_build_object('score', a.score, 'max', a.max_score, 'late', a.late, 'details', coalesce((
    select jsonb_agg(jsonb_build_object(
      'question_id', q.id, 'position', q.position, 'prompt', q.prompt, 'type', q.type, 'topic', q.topic,
      'is_correct', ans.is_correct, 'points', ans.points_awarded, 'max_points', q.points, 'answer', ans.answer,
      'explanation', k.explanation, 'common_mistake', k.common_mistake,
      'correct_answer', case q.type
        when 'mcq' then (select to_jsonb(array_agg(c.label order by c.position)) from quiz_choices c where c.id = any(k.correct_choice_ids))
        when 'numeric' then to_jsonb(k.numeric_answer)
        else to_jsonb(k.keywords) end
    ) order by q.position)
    from quiz_questions q
    left join quiz_answers ans on ans.attempt_id = a.id and ans.question_id = q.id
    left join question_keys k on k.question_id = q.id
    where q.quiz_id = a.quiz_id), '[]'::jsonb));
end $$;

revoke execute on function public.start_attempt(uuid), public.submit_attempt(uuid, jsonb), public.attempt_review(uuid) from public, anon;
grant  execute on function public.start_attempt(uuid), public.submit_attempt(uuid, jsonb), public.attempt_review(uuid) to authenticated;
