-- Migration 0002 : référentiel PROVISOIRE (à valider/modifier par l'administrateur).
-- Aucune donnée d'élève ici : les comptes sont créés via l'inscription contrôlée.
insert into public.schools (name) values
  ('Lycée Hérédité d''Abéna'), ('Lycée Saint Benoît de Gassi')
on conflict do nothing;

insert into public.classes (name, level, sort_order, is_provisional) values
  ('Première scientifique', 'Lycée', 10, true),
  ('Terminale C', 'Lycée', 20, true),
  ('Terminale D', 'Lycée', 21, true)
on conflict do nothing;
