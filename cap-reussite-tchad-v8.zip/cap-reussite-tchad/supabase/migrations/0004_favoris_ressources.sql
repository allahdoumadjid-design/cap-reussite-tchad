-- Migration 0004 : favoris et documents téléchargeables.
create table public.student_favorites (
  student_id uuid not null references public.profiles(id) on delete cascade,
  lesson_id uuid not null references public.lessons(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (student_id, lesson_id)
);
create table public.lesson_resources (
  id uuid primary key default gen_random_uuid(),
  lesson_id uuid not null references public.lessons(id) on delete cascade,
  title text not null,
  file_path text not null,                 -- chemin dans le bucket privé « ressources »
  mime_type text,
  size_bytes bigint check (size_bytes is null or size_bytes >= 0),
  created_at timestamptz not null default now()
);
create index on public.student_favorites (student_id);
create index on public.lesson_resources (lesson_id);

alter table public.student_favorites enable row level security;
alter table public.lesson_resources  enable row level security;
create policy favorites_own on public.student_favorites for all
  using (student_id = auth.uid() and public.is_active_user())
  with check (student_id = auth.uid() and public.is_active_user());
create policy resources_read  on public.lesson_resources for select using (public.is_active_user());
create policy resources_admin on public.lesson_resources for all using (public.is_admin()) with check (public.is_admin());

-- Stockage privé : lecture par comptes actifs (via liens signés courts), écriture par admin.
insert into storage.buckets (id, name, public) values ('ressources', 'ressources', false) on conflict (id) do nothing;
create policy ressources_read on storage.objects for select
  using (bucket_id = 'ressources' and public.is_active_user());
create policy ressources_admin on storage.objects for all
  using (bucket_id = 'ressources' and public.is_admin()) with check (bucket_id = 'ressources' and public.is_admin());
