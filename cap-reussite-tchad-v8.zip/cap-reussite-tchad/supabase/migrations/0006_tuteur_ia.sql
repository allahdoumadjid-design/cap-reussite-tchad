-- Migration 0006 : tuteur IA. Les écritures passent par le serveur (clé service-role) ; l'élève ne peut que lire/supprimer ses conversations.
create table public.ai_conversations (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.profiles(id) on delete cascade,
  mode text not null check (mode in ('explique','exercice','interroge','bac')),
  title text not null default 'Conversation',
  created_at timestamptz not null default now()
);
create table public.ai_messages (
  id bigint generated always as identity primary key,
  conversation_id uuid not null references public.ai_conversations(id) on delete cascade,
  role text not null check (role in ('user','assistant')),
  content text not null check (char_length(content) <= 8000),
  created_at timestamptz not null default now()
);
create table public.ai_usage (
  student_id uuid not null references public.profiles(id) on delete cascade,
  day date not null default current_date,
  requests int not null default 0,
  primary key (student_id, day)
);
create index on public.ai_conversations (student_id, created_at desc);
create index on public.ai_messages (conversation_id, id);

alter table public.ai_conversations enable row level security;
alter table public.ai_messages      enable row level security;
alter table public.ai_usage         enable row level security;   -- aucune politique : accès service-role uniquement

create policy ai_conv_read   on public.ai_conversations for select using (student_id = auth.uid());
create policy ai_conv_delete on public.ai_conversations for delete using (student_id = auth.uid());
create policy ai_msg_read on public.ai_messages for select
  using (exists (select 1 from public.ai_conversations c where c.id = conversation_id and c.student_id = auth.uid()));

-- Limite quotidienne atomique : renvoie false si la limite est atteinte.
create or replace function public.ai_consume(p_student uuid, p_limit int) returns boolean
language plpgsql security definer set search_path = public as $$
declare n int;
begin
  insert into ai_usage (student_id, day, requests) values (p_student, current_date, 1)
  on conflict (student_id, day) do update set requests = ai_usage.requests + 1 where ai_usage.requests < p_limit
  returning requests into n;
  return n is not null;
end $$;
revoke all on function public.ai_consume(uuid, int) from public, anon, authenticated;
grant execute on function public.ai_consume(uuid, int) to service_role;
