"use client";
import { useEffect, useState } from "react";

// Compte à rebours ; à zéro, envoie automatiquement le formulaire (la base compte le retard de toute façon).
export default function Minuteur({ finISO, formId }: { finISO: string; formId: string }) {
  const [reste, setReste] = useState<number | null>(null);
  useEffect(() => {
    const calcul = () => Math.max(0, Math.floor((new Date(finISO).getTime() - Date.now()) / 1000));
    setReste(calcul());
    const t = setInterval(() => {
      const r = calcul(); setReste(r);
      if (r === 0) { clearInterval(t); (document.getElementById(formId) as HTMLFormElement | null)?.requestSubmit(); }
    }, 1000);
    return () => clearInterval(t);
  }, [finISO, formId]);
  if (reste === null) return null;
  const mm = String(Math.floor(reste / 60)).padStart(2, "0"), ss = String(reste % 60).padStart(2, "0");
  return <p role="timer" className={"font-mono text-xl font-bold " + (reste < 60 ? "text-red-700" : "text-marine-800")}>Temps restant : {mm}:{ss}</p>;
}
