"use client";
// Bouton de suppression : demande une confirmation avant d'envoyer le formulaire.
export default function BoutonConfirmer({ message, className, children }: { message: string; className?: string; children: React.ReactNode }) {
  return <button type="submit" className={className} onClick={(e) => { if (!window.confirm(message)) e.preventDefault(); }}>{children}</button>;
}
