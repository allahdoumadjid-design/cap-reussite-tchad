export default function Message({ ok, erreur }: { ok?: string; erreur?: string }) {
  if (erreur) return <p role="alert" className="rounded border-l-4 border-red-600 bg-red-50 p-3 text-red-800">{erreur}</p>;
  if (ok) return <p role="status" className="rounded border-l-4 border-succes-500 bg-green-50 p-3 text-succes-600">{ok}</p>;
  return null;
}
