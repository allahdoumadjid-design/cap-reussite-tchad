"use client";
import { useRef, useState } from "react";

type Msg = { role: "user" | "assistant"; content: string };
const MODES: [string, string][] = [["explique", "Explique-moi simplement"], ["exercice", "Résolvons l'exercice ensemble"], ["interroge", "Interroge-moi"], ["bac", "Prépare-moi au bac"]];
const ERREURS: Record<string, string> = {
  limite_quotidienne: "Vous avez atteint votre limite de questions pour aujourd'hui. Revenez demain.",
  trop_rapide: "Doucement : attendez quelques secondes avant le message suivant.",
  service_sature: "Le service d'IA est très sollicité. Réessayez dans une minute.",
  fournisseur: "Le tuteur n'a pas pu répondre. Réessayez.",
  non_configure: "Le tuteur n'est pas encore activé sur cette plateforme.",
  message_trop_long: "Message trop long (2000 caractères maximum).",
};

export default function Tuteur({ initial, conversationId, modeInitial }: { initial: Msg[]; conversationId?: string; modeInitial?: string }) {
  const [msgs, setMsgs] = useState<Msg[]>(initial);
  const [mode, setMode] = useState(modeInitial ?? "explique");
  const [conv, setConv] = useState<string | undefined>(conversationId);
  const [texte, setTexte] = useState(""); const [matiere, setMatiere] = useState(""); const [chapitre, setChapitre] = useState("");
  const [charge, setCharge] = useState(false); const [erreur, setErreur] = useState<string | null>(null);
  const fin = useRef<HTMLDivElement>(null);
  const champ = "w-full rounded border border-slate-400 px-3 py-2";

  async function envoyer(e: React.FormEvent) {
    e.preventDefault();
    const message = texte.trim(); if (!message || charge) return;
    setErreur(null); setCharge(true);
    try {
      const r = await fetch("/api/tuteur", { method: "POST", headers: { "content-type": "application/json" },
        body: JSON.stringify({ mode, message, conversationId: conv, matiere, chapitre }) });
      const d = await r.json().catch(() => ({}));
      if (!r.ok) setErreur(ERREURS[d.erreur] ?? "Une erreur est survenue. Réessayez.");
      else { setMsgs((m) => [...m, { role: "user", content: message }, { role: "assistant", content: d.reponse }]); setConv(d.conversationId); setTexte(""); }
    } catch { setErreur("Connexion impossible. Vérifiez votre réseau puis réessayez : votre message est conservé."); }
    setCharge(false);
    setTimeout(() => fin.current?.scrollIntoView({ behavior: "smooth" }), 50);
  }
  return (<div className="space-y-4">
    <fieldset disabled={!!conv}><legend className="mb-1 font-medium">Que voulez-vous faire ?</legend>
      <div className="flex flex-wrap gap-2">{MODES.map(([k, n]) => (
        <label key={k} className={"cursor-pointer rounded border px-3 py-1.5 " + (mode === k ? "border-marine-800 bg-marine-800 text-white" : "border-slate-400")}>
          <input type="radio" name="mode" value={k} checked={mode === k} onChange={() => setMode(k)} className="sr-only" />{n}</label>))}</div>
      {conv && <p className="mt-1 text-sm text-slate-700">Le mode est fixé pour cette conversation. Commencez-en une nouvelle pour en changer.</p>}</fieldset>
    <div className="grid gap-3 sm:grid-cols-2">
      <div><label htmlFor="matiere" className="mb-1 block text-sm">Matière (facultatif)</label><input id="matiere" value={matiere} onChange={(e) => setMatiere(e.target.value)} maxLength={100} className={champ} /></div>
      <div><label htmlFor="chapitre" className="mb-1 block text-sm">Chapitre (facultatif)</label><input id="chapitre" value={chapitre} onChange={(e) => setChapitre(e.target.value)} maxLength={100} className={champ} /></div></div>
    <div aria-live="polite" className="space-y-3">
      {msgs.length === 0 && <p className="text-slate-700">Posez votre première question ci-dessous.</p>}
      {msgs.map((m, i) => (<div key={i} className={"whitespace-pre-wrap rounded-lg p-3 " + (m.role === "user" ? "ml-8 bg-marine-50" : "mr-8 border")}>
        <p className="mb-1 text-sm font-semibold text-marine-800">{m.role === "user" ? "Vous" : "Tuteur"}</p>{m.content}</div>))}
      {charge && <p className="text-slate-700">Le tuteur réfléchit…</p>}<div ref={fin} /></div>
    {erreur && <p role="alert" className="text-red-700">{erreur}</p>}
    <form onSubmit={envoyer} className="space-y-2">
      <label htmlFor="msg" className="block font-medium">Votre message</label>
      <textarea id="msg" value={texte} onChange={(e) => setTexte(e.target.value)} rows={3} maxLength={2000} className={champ} />
      <div className="flex items-center gap-3"><button disabled={charge || !texte.trim()} className="rounded bg-action-500 px-5 py-2 font-semibold text-marine-900 disabled:opacity-60">Envoyer</button>
        <span className="text-sm text-slate-700">{texte.length} / 2000</span></div></form>
    <p className="text-sm text-slate-700">Le tuteur peut se tromper : vérifiez dans votre cours ou avec votre enseignant.</p>
  </div>);
}
