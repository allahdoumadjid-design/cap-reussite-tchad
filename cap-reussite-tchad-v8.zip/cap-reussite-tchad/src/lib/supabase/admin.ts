import "server-only";
import { createClient } from "@supabase/supabase-js";

/** Client service-role : SERVEUR UNIQUEMENT. Contourne la RLS ; à n'utiliser qu'après avoir vérifié l'identité. */
export const createAdminClient = () =>
  createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, { auth: { persistSession: false } });
