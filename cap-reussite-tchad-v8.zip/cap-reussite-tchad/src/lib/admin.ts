import { redirect } from "next/navigation";

export const champ = "w-full rounded border border-slate-400 px-3 py-2";
export const btn = "rounded bg-marine-800 px-3 py-1.5 font-semibold text-white";
export const btnDanger = "rounded border border-red-700 px-3 py-1.5 font-semibold text-red-700";

/** Redirige avec un message de réussite ou d'erreur affiché en haut de la page. */
export function aller(chemin: string, type: "ok" | "erreur", message: string): never {
  redirect(`${chemin}${chemin.includes("?") ? "&" : "?"}${type}=${encodeURIComponent(message)}`);
}
export const estUuid = (s: string) => /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(s);

// Format de rédaction d'une leçon :  "## type | Titre" puis le texte.
// Types : objectifs, definition, formule, exemple, erreur, resume, texte
export type Section = { type: string; titre: string; texte: string };
const TYPES = ["objectifs", "definition", "formule", "exemple", "erreur", "resume", "texte"];

export function lireSections(brut: string): Section[] {
  const sections: Section[] = []; let cur: Section | null = null;
  for (const ligne of brut.replace(/\r/g, "").split("\n")) {
    const m = ligne.match(/^##\s+(.*)$/);
    if (m) {
      const [a, ...reste] = m[1].split("|");
      const avecType = reste.length > 0;
      const type = avecType ? a.trim().toLowerCase() : "texte";
      cur = { type: TYPES.includes(type) ? type : "texte", titre: (avecType ? reste.join("|") : m[1]).trim(), texte: "" };
      sections.push(cur);
    } else if (cur) cur.texte += (cur.texte ? "\n" : "") + ligne;
  }
  return sections.map((s) => ({ ...s, texte: s.texte.trim() })).filter((s) => s.titre);
}
export const ecrireSections = (s: Section[]) => s.map((x) => `## ${x.type ?? "texte"} | ${x.titre}\n${x.texte}`).join("\n\n");
