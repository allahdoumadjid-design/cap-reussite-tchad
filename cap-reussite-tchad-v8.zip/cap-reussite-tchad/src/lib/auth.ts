import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export type Profil = {
  id: string; display_name: string; role: "student" | "admin"; is_active: boolean;
  class_id: string | null; classes: { name: string } | null; schools: { name: string } | null;
};

export async function requireProfil(): Promise<Profil> {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/connexion");
  const { data } = await supabase.from("profiles")
    .select("id, display_name, role, is_active, class_id, classes(name), schools(name)")
    .eq("id", user.id).single();
  if (!data) redirect("/connexion");
  return data as unknown as Profil;
}

export async function requireAdmin(): Promise<Profil> {
  const p = await requireProfil();
  if (p.role !== "admin" || !p.is_active) redirect("/tableau-de-bord");
  return p;
}
