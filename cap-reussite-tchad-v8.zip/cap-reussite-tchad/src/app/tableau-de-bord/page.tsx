import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { requireProfil } from "@/lib/auth";
import Entete from "@/components/Entete";

export default async function TableauDeBord() {
  const profil = await requireProfil();
  if (!profil.is_active) {
    return (<><Entete profil={profil} /><main className="mx-auto max-w-2xl px-6 py-16">
      <h1 className="text-2xl font-bold text-marine-900">Compte en attente d'activation</h1>
      <p className="mt-3">Un administrateur doit activer votre compte et vous attribuer une classe.</p></main></>);
  }
  const supabase = createClient();
  const { count: total } = await supabase.from("lessons").select("id", { count: "exact", head: true });
  const { data: faites } = await supabase.from("student_progress")
    .select("lesson_id, completed, last_viewed_at, lessons(title)")
    .eq("student_id", profil.id).order("last_viewed_at", { ascending: false });
  const { data: favoris } = await supabase.from("student_favorites").select("lesson_id, lessons(title)").eq("student_id", profil.id).limit(5);
  const { data: essais } = await supabase.from("quiz_attempts").select("id, score, max_score, submitted_at, quizzes(title)")
    .eq("student_id", profil.id).eq("status", "submitted").order("submitted_at", { ascending: false }).limit(5);
  const { data: reps } = await supabase.from("quiz_answers").select("is_correct, quiz_questions(topic)");
  const parNotion = new Map<string, { ok: number; ko: number }>();
  (reps ?? []).forEach((r: any) => { const t = r.quiz_questions?.topic; if (!t) return; const c = parNotion.get(t) ?? { ok: 0, ko: 0 }; r.is_correct ? c.ok++ : c.ko++; parNotion.set(t, c); });
  const aRetravailler = Array.from(parNotion).filter(([, c]) => c.ko > c.ok).map(([t]) => t);
  const pointsForts = Array.from(parNotion).filter(([, c]) => c.ko === 0 && c.ok >= 2).map(([t]) => t);
  const terminees = (faites ?? []).filter((p: any) => p.completed).length;
  const pct = total ? Math.round((terminees / total) * 100) : 0;
  return (<>
    <Entete profil={profil} />
    <main className="mx-auto max-w-5xl space-y-8 px-4 py-8">
      <div>
        <h1 className="text-3xl font-bold text-marine-900">Bonjour, {profil.display_name}</h1>
        <p className="text-slate-700">{profil.classes?.name ?? "Classe non attribuée"}{profil.schools ? " · " + profil.schools.name : ""}</p>
      </div>
      <section aria-labelledby="prog" className="rounded-lg border p-5">
        <h2 id="prog" className="text-xl font-semibold">Progression générale</h2>
        <div className="mt-3 h-3 overflow-hidden rounded bg-slate-200" role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100}>
          <div className="h-full bg-succes-500" style={{ width: pct + "%" }} /></div>
        <p className="mt-2">{terminees} leçon(s) terminée(s) sur {total ?? 0} ({pct} %)</p>
      </section>
      <section aria-labelledby="recent" className="rounded-lg border p-5">
        <h2 id="recent" className="text-xl font-semibold">Consultées récemment</h2>
        {(faites ?? []).length === 0 ? (
          <p className="mt-2 text-slate-700">Rien pour l'instant. <Link href="/cours" className="text-marine-600 underline">Ouvrez votre première leçon.</Link></p>
        ) : (<ul className="mt-2 space-y-1">{(faites ?? []).slice(0, 5).map((p: any) => (
          <li key={p.lesson_id}><Link href={`/cours/${p.lesson_id}`} className="text-marine-600 underline">{p.lessons?.title}</Link>{p.completed && " ✓"}</li>))}</ul>)}
      </section>
      <section aria-labelledby="favs" className="rounded-lg border p-5">
        <h2 id="favs" className="text-xl font-semibold">Mes favoris</h2>
        {(favoris ?? []).length === 0 ? <p className="mt-2 text-slate-700">Aucun favori pour l'instant.</p>
          : <ul className="mt-2 space-y-1">{(favoris ?? []).map((f: any) => <li key={f.lesson_id}><Link href={`/cours/${f.lesson_id}`} className="text-marine-600 underline">{f.lessons?.title}</Link></li>)}</ul>}
      </section>
      <section aria-labelledby="quiz" className="rounded-lg border p-5">
        <h2 id="quiz" className="text-xl font-semibold">Derniers résultats</h2>
        {(essais ?? []).length === 0 ? <p className="mt-2 text-slate-700">Aucune évaluation terminée. <Link href="/entrainement" className="text-marine-600 underline">Commencer un exercice.</Link></p>
          : <ul className="mt-2 space-y-1">{(essais ?? []).map((e: any) => <li key={e.id}><Link href={`/tentative/${e.id}`} className="text-marine-600 underline">{e.quizzes?.title}</Link> : {e.score}/{e.max_score}</li>)}</ul>}
        {aRetravailler.length > 0 && <p className="mt-3"><strong>À retravailler :</strong> {aRetravailler.join(", ")}</p>}
        {pointsForts.length > 0 && <p className="mt-1"><strong>Points forts :</strong> {pointsForts.join(", ")}</p>}
      </section>
    </main></>);
}
