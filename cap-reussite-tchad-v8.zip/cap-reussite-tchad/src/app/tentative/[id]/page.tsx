import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { requireProfil } from "@/lib/auth";
import Entete from "@/components/Entete";
import Minuteur from "@/components/Minuteur";

export default async function Tentative({ params, searchParams }: { params: { id: string }; searchParams: { erreur?: string } }) {
  const profil = await requireProfil();
  const supabase = createClient();
  const { data: t } = await supabase.from("quiz_attempts").select("id, quiz_id, status, started_at").eq("id", params.id).eq("student_id", profil.id).maybeSingle();
  if (!t) notFound();
  const { data: z } = await supabase.from("quizzes").select("title, time_limit_minutes").eq("id", t.quiz_id).single();
  const { data: questions } = await supabase.from("quiz_questions").select("id, position, type, multiple, prompt, points, quiz_choices(id, label, position)")
    .eq("quiz_id", t.quiz_id).order("position");

  if (t.status === "in_progress") {
    async function soumettre(f: FormData) {
      "use server";
      const reponses: Record<string, string | string[]> = {};
      for (const [cle, val] of f.entries()) {
        if (!cle.startsWith("q_") || typeof val !== "string") continue;
        const id = cle.slice(2), v = val.slice(0, 2000), cur = reponses[id];
        reponses[id] = cur === undefined ? v : Array.isArray(cur) ? [...cur, v] : [cur, v];
      }
      const { error } = await createClient().rpc("submit_attempt", { p_attempt_id: params.id, p_answers: reponses });
      redirect(`/tentative/${params.id}` + (error ? "?erreur=1" : ""));
    }
    const fin = z?.time_limit_minutes ? new Date(new Date(t.started_at).getTime() + z.time_limit_minutes * 60000).toISOString() : null;
    const champ = "rounded border border-slate-400 px-3 py-2";
    return (<><Entete profil={profil} />
      <main className="mx-auto max-w-3xl space-y-6 px-4 py-8">
        <h1 className="text-2xl font-bold text-marine-900">{z?.title}</h1>
        {fin && <Minuteur finISO={fin} formId="evaluation" />}
        {searchParams.erreur && <p role="alert" className="text-red-700">L'envoi a échoué. Vérifiez votre connexion puis réessayez : vos réponses sont toujours à l'écran.</p>}
        <form id="evaluation" action={soumettre} className="space-y-6">
          {(questions ?? []).map((q: any, i: number) => (
            <fieldset key={q.id} className="space-y-2 rounded-lg border p-4">
              <legend className="px-1 font-semibold">Question {i + 1} ({q.points} pt{q.points > 1 ? "s" : ""})</legend>
              <p className="whitespace-pre-line">{q.prompt}</p>
              {q.type === "mcq" && [...(q.quiz_choices ?? [])].sort((a: any, b: any) => a.position - b.position).map((c: any) => (
                <label key={c.id} className="flex items-center gap-2"><input type={q.multiple ? "checkbox" : "radio"} name={"q_" + q.id} value={c.id} /> {c.label}</label>))}
              {q.type === "numeric" && <div><label htmlFor={"q_" + q.id} className="mr-2">Votre réponse (nombre)</label><input id={"q_" + q.id} name={"q_" + q.id} inputMode="decimal" className={champ} /></div>}
              {q.type === "open" && <div><label htmlFor={"q_" + q.id} className="sr-only">Votre réponse</label><textarea id={"q_" + q.id} name={"q_" + q.id} rows={4} maxLength={2000} className={champ + " w-full"} /></div>}
            </fieldset>))}
          <button className="rounded bg-action-500 px-5 py-2.5 font-semibold text-marine-900">Envoyer mes réponses</button>
        </form>
      </main></>);
  }

  const { data: bilan } = await supabase.rpc("attempt_review", { p_attempt_id: t.id });
  const details: any[] = bilan?.details ?? [];
  const libelles = new Map<string, string>();
  (questions ?? []).forEach((q: any) => (q.quiz_choices ?? []).forEach((c: any) => libelles.set(c.id, c.label)));
  const montrer = (d: any) => {
    const a = d.answer; if (a === null || a === undefined) return "Pas de réponse";
    if (d.type === "mcq") return (Array.isArray(a) ? a : [a]).map((x: string) => libelles.get(x) ?? "?").join(", ");
    return String(a);
  };
  const aRevoir = Array.from(new Set(details.filter((d) => !d.is_correct && d.topic).map((d) => d.topic as string)));
  const pct = bilan?.max ? Math.round((bilan.score / bilan.max) * 100) : 0;
  return (<><Entete profil={profil} />
    <main className="mx-auto max-w-3xl space-y-6 px-4 py-8">
      <h1 className="text-2xl font-bold text-marine-900">{z?.title} : résultat</h1>
      <p className="text-3xl font-bold text-succes-600">{bilan?.score} / {bilan?.max} ({pct} %)</p>
      {bilan?.late && <p className="text-red-700">Rendu après le temps imparti.</p>}
      {aRevoir.length > 0 && <p className="rounded border-l-4 border-action-500 bg-orange-50 p-3"><strong>À réviser :</strong> {aRevoir.join(", ")}.</p>}
      {details.map((d, i) => (<section key={d.question_id} className={"rounded-lg border p-4 " + (d.is_correct ? "border-succes-500" : "border-red-400")}>
        <h2 className="font-semibold">Question {i + 1} : {d.is_correct ? "juste" : "à revoir"} ({d.points}/{d.max_points})</h2>
        <p className="whitespace-pre-line">{d.prompt}</p>
        <p className="mt-2"><strong>Votre réponse :</strong> {montrer(d)}</p>
        <p><strong>Réponse attendue :</strong> {d.type === "open" ? "éléments attendus : " + (d.correct_answer ?? []).join(", ") : Array.isArray(d.correct_answer) ? d.correct_answer.join(", ") : String(d.correct_answer ?? "")}</p>
        {d.explanation && <p className="mt-2"><strong>Correction :</strong> {d.explanation}</p>}
        {!d.is_correct && d.common_mistake && <p className="mt-1 text-orange-800"><strong>Erreur fréquente :</strong> {d.common_mistake}</p>}
        {d.type === "open" && <p className="mt-1 text-sm text-slate-700">Question ouverte : notée de façon approximative d'après les éléments attendus.</p>}
      </section>))}
      <Link href={`/quiz/${t.quiz_id}`} className="inline-block text-marine-600 underline">Retour à l'évaluation</Link>
    </main></>);
}
