import ListeQuiz from "@/components/ListeQuiz";
export default function Page() {
  return <ListeQuiz titre="Exercices et quiz" kinds={["exercise", "lesson_quiz", "chapter_quiz", "subject_eval"]} />;
}
