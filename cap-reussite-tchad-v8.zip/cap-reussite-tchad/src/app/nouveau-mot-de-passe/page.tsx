"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export default function NouveauMotDePasse() {
  const router = useRouter();
  const [erreur, setErreur] = useState<string | null>(null);
  async function envoyer(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setErreur(null);
    const f = new FormData(e.currentTarget);
    const mdp = String(f.get("mdp"));
    if (mdp !== String(f.get("confirmation"))) return setErreur("Les deux mots de passe sont différents.");
    const { error } = await createClient().auth.updateUser({ password: mdp });
    if (error) setErreur("Changement impossible : " + error.message);
    else { router.push("/tableau-de-bord"); router.refresh(); }
  }
  const champ = "w-full rounded border border-slate-400 px-3 py-2";
  return (<main className="mx-auto max-w-md px-6 py-16">
    <h1 className="mb-6 text-2xl font-bold text-marine-900">Choisir un nouveau mot de passe</h1>
    <form onSubmit={envoyer} className="space-y-4">
      <div><label htmlFor="mdp" className="mb-1 block font-medium">Nouveau mot de passe (8 caractères minimum)</label>
        <input id="mdp" name="mdp" type="password" required minLength={8} autoComplete="new-password" className={champ} /></div>
      <div><label htmlFor="confirmation" className="mb-1 block font-medium">Confirmer le mot de passe</label>
        <input id="confirmation" name="confirmation" type="password" required minLength={8} autoComplete="new-password" className={champ} /></div>
      {erreur && <p role="alert" className="text-red-700">{erreur}</p>}
      <button className="w-full rounded bg-action-500 px-4 py-2 font-semibold text-marine-900">Enregistrer</button>
    </form>
  </main>);
}
