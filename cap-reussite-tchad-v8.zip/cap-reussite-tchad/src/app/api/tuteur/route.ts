import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { appelerFournisseur, construireSysteme, fenetreHistorique, lireConfigIA, validerRequete, type Mode, type Msg } from "@/lib/tuteur";

export const maxDuration = 60;
const err = (erreur: string, status: number) => NextResponse.json({ erreur }, { status });

export async function POST(request: Request) {
  const cfg = lireConfigIA(process.env);
  if (!cfg || !process.env.SUPABASE_SERVICE_ROLE_KEY) return err("non_configure", 503);

  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return err("non_connecte", 401);
  const { data: profil } = await supabase.from("profiles").select("display_name, is_active, classes(name)").eq("id", user.id).single();
  if (!profil?.is_active) return err("compte_inactif", 403);

  if (Number(request.headers.get("content-length") ?? 0) > 10_000) return err("requete_trop_grande", 413);
  let corps: unknown;
  try { corps = await request.json(); } catch { return err("requete_invalide", 400); }
  const v = validerRequete(corps);
  if (!v.ok) return err(v.raison, 400);
  const { message, matiere, chapitre } = v.valeur;
  let { mode, conversationId } = v.valeur;

  const admin = createAdminClient();
  let historique: Msg[] = [];
  if (conversationId) {
    const { data: conv } = await supabase.from("ai_conversations").select("id, mode").eq("id", conversationId).maybeSingle(); // RLS : la sienne uniquement
    if (!conv) return err("conversation_introuvable", 404);
    mode = conv.mode as Mode;
    const { data: anciens } = await admin.from("ai_messages").select("role, content, created_at").eq("conversation_id", conv.id).order("id", { ascending: false }).limit(12);
    if (anciens?.[0] && Date.now() - new Date(anciens[0].created_at).getTime() < 3000) return err("trop_rapide", 429);
    historique = (anciens ?? []).reverse().map((m: any) => ({ role: m.role, content: m.content }));
  }

  const { data: autorise } = await admin.rpc("ai_consume", { p_student: user.id, p_limit: cfg.limiteJour });
  if (!autorise) return err("limite_quotidienne", 429);

  let nouvelle = false;
  if (!conversationId) {
    const { data: c, error } = await admin.from("ai_conversations").insert({ student_id: user.id, mode, title: message.slice(0, 60) }).select("id").single();
    if (error || !c) return err("erreur_interne", 500);
    conversationId = c.id; nouvelle = true;
  }

  const systeme = construireSysteme(mode, { classe: (profil as any).classes?.name, nom: profil.display_name, matiere, chapitre });
  const res = await appelerFournisseur(cfg, systeme, fenetreHistorique([...historique, { role: "user", content: message }]));
  if (!res.ok) {
    console.error("[tuteur] échec fournisseur :", res.raison); // aucun contenu de conversation dans les journaux
    if (nouvelle) await admin.from("ai_conversations").delete().eq("id", conversationId);
    return err(res.raison === "limite_fournisseur" ? "service_sature" : "fournisseur", 502);
  }
  await admin.from("ai_messages").insert([
    { conversation_id: conversationId, role: "user", content: message },
    { conversation_id: conversationId, role: "assistant", content: res.texte.slice(0, 8000) },
  ]);
  return NextResponse.json({ reponse: res.texte, conversationId });
}
