import Link from "next/link";
import { notFound } from "next/navigation";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { requireAdmin } from "@/lib/auth";
import Message from "@/components/Message";
import BoutonConfirmer from "@/components/BoutonConfirmer";
import { aller, btn, btnDanger, champ, estUuid } from "@/lib/admin";

async function agir(f: FormData) {
  "use server";
  await requireAdmin();
  const sb = createClient();
  const v = (k: string) => String(f.get(k) ?? "").trim();
  const op = v("op"), id = v("id"), page = `/admin/quiz/${id}`;
  if (!estUuid(id)) aller("/admin/quiz", "erreur", "Évaluation invalide.");
  if (op === "suppr_question") {
    if (!estUuid(v("qid"))) aller(page, "erreur", "Question invalide.");
    await sb.from("quiz_questions").delete().eq("id", v("qid")).eq("quiz_id", id);
    revalidatePath(page); aller(page, "ok", "Question supprimée.");
  }
  if (op !== "question") aller(page, "erreur", "Action inconnue.");

  const type = v("type"), prompt = v("prompt"), explication = v("explication");
  const points = Number(v("points") || "1");
  if (!["mcq", "numeric", "open"].includes(type)) aller(page, "erreur", "Type de question invalide.");
  if (prompt.length < 3 || prompt.length > 4000) aller(page, "erreur", "L'énoncé doit contenir entre 3 et 4000 caractères.");
  if (explication.length < 3) aller(page, "erreur", "La correction détaillée est obligatoire.");
  if (!(points > 0 && points <= 100)) aller(page, "erreur", "Points : un nombre entre 0 et 100.");

  const choix = v("choix").split("\n").map((l) => l.trim()).filter(Boolean).map((l) => ({ correct: l.startsWith("*"), label: l.replace(/^\*\s*/, "").slice(0, 300) }));
  const numerique = v("numerique").replace(",", "."), tolerance = Number(v("tolerance").replace(",", ".") || "0");
  const motsCles = v("motscles").split(",").map((m) => m.trim()).filter(Boolean).slice(0, 20);
  if (type === "mcq" && (choix.length < 2 || !choix.some((c) => c.correct))) aller(page, "erreur", "QCM : au moins 2 choix, dont un précédé de * (bonne réponse).");
  if (type === "numeric" && (numerique === "" || Number.isNaN(Number(numerique)) || !(tolerance >= 0))) aller(page, "erreur", "Réponse numérique ou tolérance invalide.");
  if (type === "open" && motsCles.length === 0) aller(page, "erreur", "Question ouverte : indiquez au moins un mot-clé attendu.");

  const { count } = await sb.from("quiz_questions").select("id", { count: "exact", head: true }).eq("quiz_id", id);
  const { data: q, error } = await sb.from("quiz_questions").insert({ quiz_id: id, position: (count ?? 0) + 1, type, multiple: f.get("multiple") === "on",
    prompt, topic: v("notion").slice(0, 120) || null, points }).select("id").single();
  if (error || !q) aller(page, "erreur", "Création de la question impossible.");
  let ids: string[] = [], echec = false;
  if (type === "mcq") {
    const { data: ch, error: e2 } = await sb.from("quiz_choices").insert(choix.map((c, i) => ({ question_id: q.id, label: c.label, position: i + 1 }))).select("id, position");
    if (e2 || !ch) echec = true; else ids = ch.filter((c: any) => choix[c.position - 1].correct).map((c: any) => c.id);
  }
  if (!echec) {
    const { error: e3 } = await sb.from("question_keys").insert({ question_id: q.id, correct_choice_ids: ids,
      numeric_answer: type === "numeric" ? Number(numerique) : null, numeric_tolerance: type === "numeric" ? tolerance : 0,
      keywords: type === "open" ? motsCles : [], explanation: explication, common_mistake: v("erreur") || null });
    echec = !!e3;
  }
  if (echec) { await sb.from("quiz_questions").delete().eq("id", q.id); aller(page, "erreur", "La question n'a pas pu être enregistrée en entier : rien n'a été ajouté."); }
  revalidatePath(page); aller(page, "ok", "Question ajoutée.");
}

export default async function QuizAdmin({ params, searchParams }: { params: { id: string }; searchParams: { ok?: string; erreur?: string } }) {
  await requireAdmin();
  if (!estUuid(params.id)) notFound();
  const sb = createClient();
  const { data: z } = await sb.from("quizzes").select("id, title, is_published").eq("id", params.id).maybeSingle();
  if (!z) notFound();
  const { data: qs } = await sb.from("quiz_questions").select("id, position, type, prompt, topic, points").eq("quiz_id", z.id).order("position");
  return (<main className="mx-auto max-w-3xl space-y-6 px-4 py-8">
    <Link href="/admin/quiz" className="text-marine-600 underline">← Retour aux évaluations</Link>
    <h1 className="text-3xl font-bold text-marine-900">{z.title}</h1>
    <p>{z.is_published ? "Publiée : les élèves de la classe la voient." : "Brouillon : invisible des élèves."} Il est conseillé de ne pas modifier les questions d'une évaluation déjà passée.</p>
    <Message ok={searchParams.ok} erreur={searchParams.erreur} />
    <ol className="space-y-2">{(qs ?? []).map((q: any) => (<li key={q.id} className="flex flex-wrap items-start gap-3 rounded border p-3">
      <span className="flex-1"><strong>{q.position}.</strong> {q.prompt} <span className="text-sm text-slate-700">({q.type}, {q.points} pt{q.topic ? `, notion : ${q.topic}` : ""})</span></span>
      <form action={agir}><input type="hidden" name="op" value="suppr_question" /><input type="hidden" name="id" value={z.id} /><input type="hidden" name="qid" value={q.id} />
        <BoutonConfirmer message="Supprimer cette question ?" className={btnDanger}>Supprimer</BoutonConfirmer></form></li>))}</ol>
    {(qs ?? []).length === 0 && <p>Aucune question.</p>}
    <section className="rounded-lg border p-4"><h2 className="mb-3 text-xl font-semibold">Ajouter une question</h2>
      <form action={agir} className="space-y-3"><input type="hidden" name="op" value="question" /><input type="hidden" name="id" value={z.id} />
        <div><label htmlFor="type" className="mb-1 block">Type</label><select id="type" name="type" className={champ}>
          <option value="mcq">QCM</option><option value="numeric">Réponse numérique</option><option value="open">Question ouverte</option></select></div>
        <div><label htmlFor="prompt" className="mb-1 block">Énoncé</label><textarea id="prompt" name="prompt" required rows={3} maxLength={4000} className={champ} /></div>
        <div><label htmlFor="choix" className="mb-1 block">QCM : un choix par ligne, précédez les bonnes réponses de *</label><textarea id="choix" name="choix" rows={4} className={champ + " font-mono text-sm"} placeholder={"* Bonne réponse\nMauvaise réponse"} /></div>
        <label className="flex items-center gap-2"><input type="checkbox" name="multiple" /> QCM à réponses multiples</label>
        <div className="grid gap-3 sm:grid-cols-2">
          <div><label htmlFor="numerique" className="mb-1 block">Numérique : bonne réponse</label><input id="numerique" name="numerique" inputMode="decimal" className={champ} /></div>
          <div><label htmlFor="tolerance" className="mb-1 block">Numérique : tolérance (écart accepté)</label><input id="tolerance" name="tolerance" inputMode="decimal" className={champ} /></div></div>
        <div><label htmlFor="motscles" className="mb-1 block">Question ouverte : mots-clés attendus, séparés par des virgules</label><input id="motscles" name="motscles" className={champ} /></div>
        <div><label htmlFor="explication" className="mb-1 block">Correction détaillée (raisonnement, pas seulement le résultat)</label><textarea id="explication" name="explication" required rows={4} className={champ} /></div>
        <div><label htmlFor="erreur" className="mb-1 block">Erreur fréquente (facultatif)</label><input id="erreur" name="erreur" maxLength={400} className={champ} /></div>
        <div className="grid gap-3 sm:grid-cols-2">
          <div><label htmlFor="notion" className="mb-1 block">Notion évaluée (sert aux recommandations)</label><input id="notion" name="notion" maxLength={120} className={champ} /></div>
          <div><label htmlFor="points" className="mb-1 block">Points</label><input id="points" name="points" defaultValue="1" inputMode="decimal" className={champ} /></div></div>
        <button className={btn}>Ajouter la question</button>
      </form></section>
  </main>);
}
