import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { requireAdmin } from "@/lib/auth";
import Message from "@/components/Message";
import BoutonConfirmer from "@/components/BoutonConfirmer";
import { aller, btn, btnDanger, champ, estUuid } from "@/lib/admin";

const PAGE = "/admin/roles";

async function agir(f: FormData) {
  "use server";
  const moi = await requireAdmin();
  const id = String(f.get("id") ?? ""), op = String(f.get("op") ?? "");
  if (!estUuid(id)) aller(PAGE, "erreur", "Compte invalide.");
  const sb = createClient();
  if (op === "promouvoir") {
    if (String(f.get("confirmation") ?? "").trim() !== "ADMIN") aller(PAGE, "erreur", "Tapez ADMIN pour confirmer la promotion.");
    const { error } = await sb.from("profiles").update({ role: "admin" }).eq("id", id).eq("role", "student").eq("is_active", true);
    if (error) aller(PAGE, "erreur", "Promotion refusée.");
  } else if (op === "retirer") {
    if (id === moi.id) aller(PAGE, "erreur", "Vous ne pouvez pas retirer votre propre rôle.");
    const { error } = await sb.from("profiles").update({ role: "student" }).eq("id", id).eq("role", "admin");
    if (error) aller(PAGE, "erreur", "Retrait refusé.");
  } else aller(PAGE, "erreur", "Action inconnue.");
  revalidatePath(PAGE); aller(PAGE, "ok", "Rôle mis à jour (action enregistrée dans le journal d'audit).");
}

export default async function Roles({ searchParams }: { searchParams: { ok?: string; erreur?: string } }) {
  const moi = await requireAdmin();
  const sb = createClient();
  const { data: admins } = await sb.from("profiles").select("id, display_name").eq("role", "admin").order("display_name");
  const { data: eleves } = await sb.from("profiles").select("id, display_name").eq("role", "student").eq("is_active", true).order("display_name");
  const { data: journal } = await sb.from("audit_logs").select("id, created_at, target_id, details").order("created_at", { ascending: false }).limit(10);
  return (<main className="mx-auto max-w-3xl space-y-6 px-4 py-8">
    <h1 className="text-3xl font-bold text-marine-900">Rôles et autorisations</h1>
    <Message ok={searchParams.ok} erreur={searchParams.erreur} />
    <section className="rounded-lg border p-4"><h2 className="mb-2 text-xl font-semibold">Administrateurs</h2>
      <ul className="space-y-2">{(admins ?? []).map((a: any) => (<li key={a.id} className="flex items-center gap-3"><span>{a.display_name}{a.id === moi.id && " (vous)"}</span>
        {a.id !== moi.id && <form action={agir}><input type="hidden" name="op" value="retirer" /><input type="hidden" name="id" value={a.id} />
          <BoutonConfirmer message={`Retirer le rôle administrateur à ${a.display_name} ?`} className={btnDanger}>Retirer</BoutonConfirmer></form>}</li>))}</ul></section>
    <section className="rounded-lg border p-4"><h2 className="mb-2 text-xl font-semibold">Promouvoir un élève actif</h2>
      <form action={agir} className="space-y-3"><input type="hidden" name="op" value="promouvoir" />
        <div><label htmlFor="id" className="mb-1 block">Compte</label><select id="id" name="id" required className={champ}>{(eleves ?? []).map((e: any) => <option key={e.id} value={e.id}>{e.display_name}</option>)}</select></div>
        <div><label htmlFor="confirmation" className="mb-1 block">Tapez ADMIN pour confirmer</label><input id="confirmation" name="confirmation" required className={champ} autoComplete="off" /></div>
        <button className={btn}>Promouvoir</button></form></section>
    <section><h2 className="mb-2 text-xl font-semibold">Dernières modifications de comptes</h2>
      {(journal ?? []).length === 0 ? <p>Aucune modification enregistrée.</p> : <ul className="space-y-1 text-sm">{(journal ?? []).map((j: any) => (<li key={j.id}>{new Date(j.created_at).toLocaleString("fr-FR")} : {JSON.stringify(j.details)}</li>))}</ul>}</section>
  </main>);
}
