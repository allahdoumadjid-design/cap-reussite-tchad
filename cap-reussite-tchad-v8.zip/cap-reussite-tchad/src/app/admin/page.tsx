import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { requireAdmin } from "@/lib/auth";
import Message from "@/components/Message";
import { aller, btn, estUuid } from "@/lib/admin";

async function mettreAJour(f: FormData) {
  "use server";
  await requireAdmin(); // la RLS et le déclencheur SQL re-vérifient côté base
  const id = String(f.get("id")), classe = String(f.get("class_id") || "");
  if (!estUuid(id) || (classe && !estUuid(classe))) aller("/admin", "erreur", "Données invalides.");
  const { error } = await createClient().from("profiles").update({ is_active: f.get("is_active") === "on", class_id: classe || null }).eq("id", id);
  if (error) aller("/admin", "erreur", "Modification refusée.");
  revalidatePath("/admin"); aller("/admin", "ok", "Élève mis à jour.");
}

export default async function Admin({ searchParams }: { searchParams: { ok?: string; erreur?: string } }) {
  await requireAdmin();
  const sb = createClient();
  const nb = (q: any) => q.then((r: any) => r.count ?? 0);
  const [eleves, actifs, lecons, quiz, essais] = await Promise.all([
    nb(sb.from("profiles").select("id", { count: "exact", head: true }).eq("role", "student")),
    nb(sb.from("profiles").select("id", { count: "exact", head: true }).eq("role", "student").eq("is_active", true)),
    nb(sb.from("lessons").select("id", { count: "exact", head: true })),
    nb(sb.from("quizzes").select("id", { count: "exact", head: true })),
    nb(sb.from("quiz_attempts").select("id", { count: "exact", head: true }).eq("status", "submitted")),
  ]);
  const { data: liste } = await sb.from("profiles").select("id, display_name, is_active, class_id").eq("role", "student").order("created_at", { ascending: false });
  const { data: classes } = await sb.from("classes").select("id, name").order("sort_order");
  const stats = [["Élèves", eleves], ["Comptes actifs", actifs], ["En attente", eleves - actifs], ["Leçons", lecons], ["Évaluations", quiz], ["Tentatives terminées", essais]];
  return (<main className="mx-auto max-w-5xl space-y-6 px-4 py-8">
    <h1 className="text-3xl font-bold text-marine-900">Vue générale</h1>
    <Message ok={searchParams.ok} erreur={searchParams.erreur} />
    <dl className="grid grid-cols-2 gap-3 sm:grid-cols-3">{stats.map(([t, n]) => (
      <div key={String(t)} className="rounded-lg border p-4"><dt className="text-sm text-slate-700">{t}</dt><dd className="text-2xl font-bold text-marine-800">{n as number}</dd></div>))}</dl>
    <h2 className="text-2xl font-bold text-marine-900">Élèves</h2>
    {(liste ?? []).length === 0 && <p>Aucune inscription pour le moment.</p>}
    {(liste ?? []).map((e: any) => (
      <form key={e.id} action={mettreAJour} className="flex flex-wrap items-center gap-4 rounded-lg border p-4">
        <input type="hidden" name="id" value={e.id} />
        <span className="min-w-40 font-medium">{e.display_name}</span>
        <label>Classe <select name="class_id" defaultValue={e.class_id ?? ""} className="rounded border px-2 py-1">
          <option value="">— aucune —</option>{(classes ?? []).map((c: any) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></label>
        <label><input type="checkbox" name="is_active" defaultChecked={e.is_active} /> Compte actif</label>
        <button className={btn}>Enregistrer</button>
      </form>))}
  </main>);
}
