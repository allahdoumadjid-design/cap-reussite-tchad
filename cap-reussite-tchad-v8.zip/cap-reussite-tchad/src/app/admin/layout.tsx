import Link from "next/link";
import { requireAdmin } from "@/lib/auth";
import Entete from "@/components/Entete";

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const profil = await requireAdmin();
  return (<><Entete profil={profil} />
    <nav aria-label="Administration" className="border-b bg-marine-50">
      <div className="mx-auto flex max-w-5xl flex-wrap gap-4 px-4 py-2 text-marine-800">
        <Link href="/admin" className="hover:underline">Vue générale et élèves</Link>
        <Link href="/admin/contenus" className="hover:underline">Cours</Link>
        <Link href="/admin/quiz" className="hover:underline">Quiz et examens</Link>
        <Link href="/admin/suivi" className="hover:underline">Suivi</Link>
        <Link href="/admin/roles" className="hover:underline">Rôles</Link>
      </div></div></nav>
    {children}</>);
}
