import { createClient } from "@/lib/supabase/server";
import { requireAdmin } from "@/lib/auth";

// Agrégation en mémoire : convient à quelques centaines d'élèves (limite de 1000 lignes par requête).
export default async function Suivi() {
  await requireAdmin();
  const sb = createClient();
  const [{ data: eleves }, { data: prog }, { data: essais }, { count: total }] = await Promise.all([
    sb.from("profiles").select("id, display_name, is_active, classes(name)").eq("role", "student").order("display_name"),
    sb.from("student_progress").select("student_id").eq("completed", true),
    sb.from("quiz_attempts").select("student_id, score, max_score").eq("status", "submitted"),
    sb.from("lessons").select("id", { count: "exact", head: true }).eq("is_published", true),
  ]);
  const faites = new Map<string, number>(), notes = new Map<string, number[]>();
  (prog ?? []).forEach((p: any) => faites.set(p.student_id, (faites.get(p.student_id) ?? 0) + 1));
  (essais ?? []).forEach((e: any) => { if (e.max_score) notes.set(e.student_id, [...(notes.get(e.student_id) ?? []), (e.score / e.max_score) * 100]); });
  return (<main className="mx-auto max-w-5xl space-y-6 px-4 py-8">
    <h1 className="text-3xl font-bold text-marine-900">Suivi des élèves</h1>
    {(eleves ?? []).length === 0 ? <p>Aucun élève inscrit.</p> : (
      <div className="overflow-x-auto"><table className="w-full border-collapse text-left">
        <thead><tr className="border-b"><th className="p-2">Élève</th><th className="p-2">Classe</th><th className="p-2">Leçons terminées</th><th className="p-2">Évaluations</th><th className="p-2">Moyenne</th></tr></thead>
        <tbody>{(eleves ?? []).map((e: any) => { const n = notes.get(e.id) ?? [];
          return (<tr key={e.id} className="border-b"><td className="p-2">{e.display_name}{!e.is_active && <span className="text-sm text-orange-800"> (inactif)</span>}</td>
            <td className="p-2">{e.classes?.name ?? "—"}</td><td className="p-2">{faites.get(e.id) ?? 0} / {total ?? 0}</td>
            <td className="p-2">{n.length}</td><td className="p-2">{n.length ? Math.round(n.reduce((a, b) => a + b, 0) / n.length) + " %" : "—"}</td></tr>); })}</tbody>
      </table></div>)}
  </main>);
}
