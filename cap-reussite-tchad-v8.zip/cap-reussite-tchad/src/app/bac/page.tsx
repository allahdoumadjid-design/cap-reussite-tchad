import ListeQuiz from "@/components/ListeQuiz";
export default function Page() {
  return <ListeQuiz titre="Préparation au baccalauréat" kinds={["bac_blanc", "bac_topic"]}
    avertissement="Sauf mention contraire, ces sujets sont des sujets d'entraînement et non des sujets officiels." />;
}
