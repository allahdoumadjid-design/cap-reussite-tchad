import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { requireProfil } from "@/lib/auth";
import Entete from "@/components/Entete";

export default async function PageQuiz({ params, searchParams }: { params: { id: string }; searchParams: { erreur?: string } }) {
  const profil = await requireProfil();
  const supabase = createClient();
  const { data: z } = await supabase.from("quizzes").select("id, title, kind, time_limit_minutes, is_official, source_note").eq("id", params.id).maybeSingle();
  if (!z) notFound();
  const { data: essais } = await supabase.from("quiz_attempts").select("id, status, score, max_score, submitted_at, late")
    .eq("quiz_id", z.id).eq("student_id", profil.id).order("started_at", { ascending: false });

  async function demarrer() {
    "use server";
    const { data, error } = await createClient().rpc("start_attempt", { p_quiz_id: params.id });
    if (error || !data) redirect(`/quiz/${params.id}?erreur=1`);
    redirect(`/tentative/${data}`);
  }
  return (<><Entete profil={profil} />
    <main className="mx-auto max-w-3xl space-y-6 px-4 py-8">
      <h1 className="text-3xl font-bold text-marine-900">{z.title}</h1>
      <p>{z.time_limit_minutes ? `Durée : ${z.time_limit_minutes} minutes. Le minuteur démarre dès que vous commencez.` : "Sans limite de temps."}</p>
      {z.kind.startsWith("bac") && !z.is_official && <p className="rounded border-l-4 border-action-500 bg-orange-50 p-3">Sujet d'entraînement non officiel. {z.source_note}</p>}
      {searchParams.erreur && <p role="alert" className="text-red-700">Impossible de démarrer l'évaluation. Réessayez.</p>}
      <form action={demarrer}><button className="rounded bg-action-500 px-5 py-2.5 font-semibold text-marine-900">{(essais ?? []).length ? "Refaire l'évaluation" : "Commencer"}</button></form>
      <section aria-labelledby="h"><h2 id="h" className="text-xl font-semibold">Mes tentatives</h2>
        {(essais ?? []).length === 0 ? <p className="mt-2">Aucune tentative pour l'instant.</p> : (
          <ul className="mt-2 space-y-1">{(essais ?? []).map((e: any) => (<li key={e.id}>
            <Link href={`/tentative/${e.id}`} className="text-marine-600 underline">
              {e.status === "submitted" ? `${e.score} / ${e.max_score}` : "En cours"}</Link>
            {e.submitted_at && <span className="text-sm text-slate-700"> · {new Date(e.submitted_at).toLocaleString("fr-FR")}</span>}
            {e.late && <span className="text-sm text-red-700"> · rendu après le temps imparti</span>}</li>))}</ul>)}
      </section>
    </main></>);
}
