import { NextResponse, type NextRequest } from "next/server";
import { createClient } from "@/lib/supabase/server";

// Échange le code reçu par e-mail contre une session, puis redirige (uniquement vers une page du site).
export async function GET(request: NextRequest) {
  const { searchParams, origin } = new URL(request.url);
  const code = searchParams.get("code");
  const next = searchParams.get("next") ?? "/tableau-de-bord";
  const sure = next.startsWith("/") && !next.startsWith("//") ? next : "/tableau-de-bord";
  if (code) {
    const { error } = await createClient().auth.exchangeCodeForSession(code);
    if (!error) return NextResponse.redirect(origin + sure);
  }
  return NextResponse.redirect(origin + "/connexion?erreur=lien");
}
