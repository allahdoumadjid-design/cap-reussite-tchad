import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "CAP RÉUSSITE TCHAD",
  description:
    "Plateforme éducative pour les élèves du secondaire au Tchad : cours, exercices corrigés, quiz, révisions et tuteur IA.",
};
export const viewport: Viewport = { width: "device-width", initialScale: 1, themeColor: "#0f2e5c" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <body className="min-h-screen bg-white text-slate-900 antialiased">{children}</body>
    </html>
  );
}
