import Link from "next/link";
export default function Accueil() {
  return (<main className="mx-auto flex min-h-screen max-w-3xl flex-col justify-center gap-6 px-6 py-16">
    <h1 className="text-4xl font-bold tracking-tight text-marine-900 sm:text-5xl">CAP RÉUSSITE TCHAD</h1>
    <p className="text-xl text-marine-800">Comprendre simplement. Apprendre durablement. Réussir avec confiance.</p>
    <p className="max-w-prose text-slate-700">Cours par classe et par matière, suivi de progression, révisions. Les quiz et le tuteur IA arrivent aux phases suivantes.</p>
    <div><Link href="/connexion" className="inline-block rounded bg-action-500 px-5 py-2.5 font-semibold text-marine-900">Se connecter ou demander un accès</Link></div>
  </main>);
}
