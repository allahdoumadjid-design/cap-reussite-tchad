-- DÉMO UNIQUEMENT (contenu fictif) : sert à tester le moteur de quiz. À supprimer ensuite.
-- Prérequis : migrations 0001 à 0005 exécutées. Les élèves doivent avoir la classe « Terminale C ».
do $$
declare z uuid; q1 uuid; q2 uuid; q3 uuid; c1 uuid; c2 uuid; c3 uuid;
begin
  insert into quizzes (class_id, kind, title, is_published, source_note)
    select id, 'exercise', '[DÉMO] Test technique — à supprimer', true, 'Contenu fictif pour tester la plateforme'
    from classes where name = 'Terminale C' returning id into z;
  insert into quiz_questions (quiz_id, position, type, prompt, topic) values (z, 1, 'mcq', 'Combien font 2 + 2 ?', 'Addition') returning id into q1;
  insert into quiz_choices (question_id, label, position) values (q1, '3', 1);
  insert into quiz_choices (question_id, label, position) values (q1, '4', 2) returning id into c2;
  insert into quiz_choices (question_id, label, position) values (q1, '5', 3);
  insert into question_keys (question_id, correct_choice_ids, explanation, common_mistake)
    values (q1, array[c2], '2 + 2 = 4 : on ajoute deux unités à deux unités.', 'Confondre l''addition et la multiplication.');
  insert into quiz_questions (quiz_id, position, type, prompt, topic) values (z, 2, 'numeric', 'Calculer 3 × 5', 'Multiplication') returning id into q2;
  insert into question_keys (question_id, numeric_answer, explanation) values (q2, 15, '3 × 5 = 5 + 5 + 5 = 15.');
  insert into quiz_questions (quiz_id, position, type, prompt, topic) values (z, 3, 'open', 'En une phrase : que signifie « résoudre une équation » ?', 'Équations') returning id into q3;
  insert into question_keys (question_id, keywords, explanation) values (q3, array['valeur','inconnue'],
    'Résoudre une équation, c''est trouver la ou les valeurs de l''inconnue qui rendent l''égalité vraie.');
end $$;
