# Architecture
- `src/lib/auth.ts` : `requireProfil` / `requireAdmin` (redirections côté serveur).
- `middleware.ts` : session + routes privées. La protection réelle des données = RLS (migration 0001).
- Contenu d'une leçon (`lessons.content`) : `{ "sections": [{ "titre": "...", "texte": "..." }] }`.
## Reste à faire
Quiz et scores côté serveur, exercices, espace bac, tuteur IA, édition des contenus dans l'admin,
page de nouveau mot de passe, tests automatisés, déploiement vérifié.
