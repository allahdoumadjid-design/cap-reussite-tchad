# Déploiement de CAP RÉUSSITE TCHAD

## 1. Avant tout : vérifier que le code compile
1. Envoyez le projet sur GitHub. L'onglet **Actions** lance automatiquement `typecheck`, `lint`, `test` et `build` (`.github/workflows/ci.yml`).
2. Corrigez les erreurs affichées (envoyez-les-moi si besoin). **Ne déployez pas tant que la CI n'est pas verte.**

## 2. Supabase (base, comptes, documents)
1. Créez un projet sur supabase.com (choisissez la région la plus proche de vos élèves).
2. SQL Editor : exécutez dans l'ordre `0001` à `0006` (dossier `supabase/migrations`).
3. Exécutez `tests/rls_tests.sql` : le résultat doit être « TOUS LES TESTS REUSSIS » (tout est annulé ensuite). Sinon, ne continuez pas.
4. Storage : vérifiez que le bucket **ressources** existe et est **privé** (sinon créez-le).
5. Authentication > URL Configuration : *Site URL* = l'adresse du site ; *Redirect URLs* = `https://VOTRE-SITE/auth/callback`.
6. Authentication > Providers > Email : activez la confirmation par e-mail ; longueur minimale du mot de passe : 8 ou plus.
7. Authentication > SMTP : configurez un service d'e-mail fiable (le service par défaut est très limité, insuffisant pour de vrais élèves).
8. Premier administrateur : créez un compte (Authentication > Users), puis dans SQL Editor :
   `update public.profiles set role = 'admin', is_active = true where id = 'UUID-DU-COMPTE';`
9. Project Settings > API : notez l'URL, la clé `anon` et la clé `service_role` (secrète).

## 3. Vercel (hébergement)
1. Importez le dépôt GitHub dans Vercel (framework : Next.js, détecté automatiquement).
2. Settings > Environment Variables (Production) :
   - `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY` (secret, jamais préfixé NEXT_PUBLIC_)
   - Tuteur IA (facultatif au départ) : `AI_PROVIDER`, `AI_API_KEY`, `AI_MODEL`, `AI_MAX_TOKENS`, `AI_DAILY_LIMIT`
3. Déployez. Le domaine personnalisé se règle dans Settings > Domains.

## 4. Tests de fumée après déploiement (à faire avec de vrais comptes)
- [ ] Inscription d'un compte test : il arrive **inactif** ; l'e-mail de confirmation est reçu.
- [ ] L'admin l'active et lui attribue une classe (/admin).
- [ ] Connexion élève ; /admin redirige vers le tableau de bord (accès refusé).
- [ ] Un utilisateur non connecté ouvrant /cours est renvoyé vers /connexion (confirme que `src/middleware.ts` est actif).
- [ ] Réinitialisation du mot de passe : e-mail reçu, lien valide, nouveau mot de passe accepté.
- [ ] Création d'une leçon publiée, lecture par l'élève, « marquer terminée », favoris.
- [ ] Téléversement d'un PDF et téléchargement par l'élève.
- [ ] Quiz : création, publication, passage, score, correction ; un second élève ne voit pas les résultats du premier.
- [ ] Tuteur IA (si configuré) : les 4 modes ; message trop long refusé ; limite quotidienne atteinte puis message clair.
- [ ] Test sur un vrai téléphone, connexion lente.

## 5. Sauvegardes et exploitation
- Supabase : vérifiez la politique de sauvegarde de votre offre (les sauvegardes automatiques dépendent du plan).
- Fixez une **limite de dépense** chez le fournisseur d'IA et surveillez sa console.
- Mettez à jour les dépendances régulièrement (`npm audit`, alertes Dependabot de GitHub).
