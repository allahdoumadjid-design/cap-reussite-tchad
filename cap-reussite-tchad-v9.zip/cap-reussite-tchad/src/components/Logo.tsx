// Identité visuelle : un sommet (« cap »), une base verte (réussite) et un point orange (le soleil du Tchad).
export default function Logo({ clair = false, className = "" }: { clair?: boolean; className?: string }) {
  return (
    <span className={"inline-flex items-center gap-2.5 " + className}>
      <svg width="36" height="36" viewBox="0 0 36 36" aria-hidden="true">
        <rect width="36" height="36" rx="9" fill={clair ? "#ffffff" : "#0f2e5c"} />
        <path d="M8 24l10-12 10 12" fill="none" stroke={clair ? "#0f2e5c" : "#ffffff"} strokeWidth="3.2" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M13 28h10" stroke="#1f9d55" strokeWidth="3.2" strokeLinecap="round" />
        <circle cx="27.5" cy="9" r="3" fill="#f28c1b" />
      </svg>
      <span className="leading-tight">
        <span className="block text-base font-extrabold tracking-tight">CAP RÉUSSITE</span>
        <span className="block text-xs font-semibold tracking-[0.25em] opacity-80">TCHAD</span>
      </span>
    </span>
  );
}
