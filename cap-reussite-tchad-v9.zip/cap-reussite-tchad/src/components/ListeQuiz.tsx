import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { requireProfil } from "@/lib/auth";
import Entete from "@/components/Entete";

const types: Record<string, string> = {
  exercise: "Exercice", lesson_quiz: "Quiz de leçon", chapter_quiz: "Quiz de chapitre",
  subject_eval: "Évaluation de matière", bac_blanc: "Examen blanc", bac_topic: "Entraînement par thème",
};

export default async function ListeQuiz({ titre, kinds, avertissement }: { titre: string; kinds: string[]; avertissement?: string }) {
  const profil = await requireProfil();
  const supabase = createClient();
  const { data: quiz } = await supabase.from("quizzes")
    .select("id, title, kind, time_limit_minutes, is_official, source_note").in("kind", kinds).order("created_at", { ascending: false });
  const { data: essais } = await supabase.from("quiz_attempts").select("quiz_id, score, max_score")
    .eq("student_id", profil.id).eq("status", "submitted");
  const meilleur = new Map<string, number>();
  (essais ?? []).forEach((e: any) => { const p = e.max_score ? Math.round((e.score / e.max_score) * 100) : 0; meilleur.set(e.quiz_id, Math.max(p, meilleur.get(e.quiz_id) ?? 0)); });
  return (<><Entete profil={profil} />
    <main id="contenu" className="mx-auto max-w-4xl space-y-6 px-4 py-8">
      <h1 className="text-3xl font-bold text-marine-900">{titre}</h1>
      {avertissement && <p className="rounded border-l-4 border-action-500 bg-orange-50 p-3">{avertissement}</p>}
      {(quiz ?? []).length === 0 ? <p>Aucune évaluation publiée pour votre classe pour le moment.</p> : (
        <ul className="space-y-3">{(quiz ?? []).map((z: any) => (
          <li key={z.id} className="rounded-lg border p-4">
            <Link href={`/quiz/${z.id}`} className="text-lg font-semibold text-marine-600 underline">{z.title}</Link>
            <p className="text-sm text-slate-700">{types[z.kind]}{z.time_limit_minutes ? ` · ${z.time_limit_minutes} min` : ""}
              {z.kind.startsWith("bac") && !z.is_official ? " · sujet non officiel" : ""}
              {meilleur.has(z.id) ? ` · meilleur score : ${meilleur.get(z.id)} %` : ""}</p>
          </li>))}</ul>)}
    </main></>);
}
