import Link from "next/link";
import Logo from "@/components/Logo";

export default function PiedDePage() {
  const contact = process.env.NEXT_PUBLIC_CONTACT_EMAIL;
  return (
    <footer className="bg-marine-900 text-white">
      <div className="mx-auto grid max-w-6xl gap-8 px-4 py-12 sm:grid-cols-3">
        <div>
          <Logo clair />
          <p className="mt-4 text-sm text-white/80">Comprendre simplement. Apprendre durablement. Réussir avec confiance.</p>
        </div>
        <nav aria-label="Liens du pied de page">
          <h2 className="mb-3 text-sm font-semibold uppercase tracking-wider text-white/60">Plateforme</h2>
          <ul className="space-y-2 text-sm">
            <li><Link href="/#fonctionnalites" className="hover:underline">Fonctionnalités</Link></li>
            <li><Link href="/#tuteur" className="hover:underline">Tuteur IA</Link></li>
            <li><Link href="/connexion" className="hover:underline">Se connecter ou demander un accès</Link></li>
          </ul>
        </nav>
        <div>
          <h2 className="mb-3 text-sm font-semibold uppercase tracking-wider text-white/60">Informations</h2>
          <ul className="space-y-2 text-sm">
            <li><Link href="/confidentialite" className="hover:underline">Confidentialité et données personnelles</Link></li>
            {contact && <li><a href={`mailto:${contact}`} className="hover:underline">{contact}</a></li>}
          </ul>
        </div>
      </div>
      <p className="border-t border-white/15 px-4 py-4 text-center text-xs text-white/60">© {new Date().getFullYear()} CAP RÉUSSITE TCHAD. Tous droits réservés.</p>
    </footer>
  );
}
