import Link from "next/link";
import Logo from "@/components/Logo";

const liens = [["/#mission", "Mission"], ["/#fonctionnalites", "Fonctionnalités"], ["/#tuteur", "Tuteur IA"], ["/#acces", "Accès"]];

export default function EntetePublic() {
  return (
    <header className="sticky top-0 z-30 bg-marine-900/95 text-white backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center gap-6 px-4 py-3">
        <Link href="/" aria-label="CAP RÉUSSITE TCHAD, accueil"><Logo clair /></Link>
        <nav aria-label="Navigation principale" className="ml-auto hidden items-center gap-6 md:flex">
          {liens.map(([h, n]) => <Link key={h} href={h} className="text-sm font-medium hover:underline">{n}</Link>)}
          <Link href="/connexion" className="rounded-lg bg-action-500 px-4 py-2 text-sm font-semibold text-marine-900 transition hover:bg-action-600 hover:text-white">Se connecter</Link>
        </nav>
        <details className="relative ml-auto md:hidden">
          <summary className="cursor-pointer list-none rounded border border-white/40 px-3 py-1.5 text-sm font-semibold">Menu</summary>
          <nav aria-label="Menu mobile" className="absolute right-0 mt-2 w-56 rounded-lg bg-white p-2 text-marine-900 shadow-lg">
            {liens.map(([h, n]) => <Link key={h} href={h} className="block rounded px-3 py-2 hover:bg-marine-50">{n}</Link>)}
            <Link href="/connexion" className="mt-1 block rounded bg-action-500 px-3 py-2 text-center font-semibold">Se connecter</Link>
          </nav>
        </details>
      </div>
    </header>
  );
}
