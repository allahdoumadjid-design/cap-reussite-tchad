import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { requireProfil } from "@/lib/auth";
import Entete from "@/components/Entete";

export default async function Catalogue({ searchParams }: { searchParams: { q?: string; matiere?: string } }) {
  const profil = await requireProfil();
  const supabase = createClient();
  const q = (searchParams.q ?? "").trim().toLowerCase().slice(0, 80);
  const { data: toutes } = profil.class_id
    ? await supabase.from("subjects").select("id, name, chapters(id, title, sort_order, lessons(id, title, sort_order))")
        .eq("class_id", profil.class_id).order("sort_order")
    : { data: [] as any[] };
  const { data: faites } = await supabase.from("student_progress").select("lesson_id").eq("student_id", profil.id).eq("completed", true);
  const ok = new Set((faites ?? []).map((p: any) => p.lesson_id));
  const matieres = (toutes ?? []).filter((m: any) => !searchParams.matiere || m.id === searchParams.matiere);
  const lien = "text-marine-600 underline";
  return (<><Entete profil={profil} />
    <main id="contenu" className="mx-auto max-w-5xl space-y-6 px-4 py-8">
      <h1 className="text-3xl font-bold text-marine-900">Mes cours</h1>
      <form method="get" className="flex flex-wrap items-end gap-3">
        <div><label htmlFor="q" className="mb-1 block font-medium">Rechercher une leçon ou un chapitre</label>
          <input id="q" name="q" defaultValue={searchParams.q ?? ""} maxLength={80} className="rounded border border-slate-400 px-3 py-2" /></div>
        <div><label htmlFor="matiere" className="mb-1 block font-medium">Matière</label>
          <select id="matiere" name="matiere" defaultValue={searchParams.matiere ?? ""} className="rounded border border-slate-400 px-3 py-2">
            <option value="">Toutes</option>{(toutes ?? []).map((m: any) => <option key={m.id} value={m.id}>{m.name}</option>)}</select></div>
        <button className="rounded bg-marine-800 px-4 py-2 font-semibold text-white">Filtrer</button>
      </form>
      {!profil.is_active || !profil.class_id ? <p>Votre compte doit être activé et rattaché à une classe pour voir les cours.</p>
        : (toutes ?? []).length === 0 ? <p>Aucun cours publié pour votre classe pour le moment.</p>
        : matieres.map((m: any) => {
          const lecons = (m.chapters ?? []).flatMap((c: any) => c.lessons ?? []);
          const fait = lecons.filter((l: any) => ok.has(l.id)).length;
          const pct = lecons.length ? Math.round((fait / lecons.length) * 100) : 0;
          const chapitres = (m.chapters ?? []).sort((a: any, b: any) => a.sort_order - b.sort_order).map((c: any) => ({
            ...c, lessons: (c.lessons ?? []).filter((l: any) => !q || l.title.toLowerCase().includes(q) || c.title.toLowerCase().includes(q))
              .sort((a: any, b: any) => a.sort_order - b.sort_order) })).filter((c: any) => c.lessons.length > 0);
          if (q && chapitres.length === 0) return null;
          return (<section key={m.id} className="rounded-lg border p-5">
            <div className="flex flex-wrap items-baseline justify-between gap-2">
              <h2 className="text-xl font-semibold text-marine-800">{m.name}</h2>
              <span className="text-sm text-slate-700">{fait}/{lecons.length} leçons ({pct} %)</span></div>
            <div className="mt-2 h-2 overflow-hidden rounded bg-slate-200" role="progressbar" aria-label={"Progression en " + m.name} aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100}>
              <div className="h-full bg-succes-500" style={{ width: pct + "%" }} /></div>
            {chapitres.map((c: any) => (<div key={c.id} className="mt-3"><h3 className="font-medium">{c.title}</h3>
              <ul className="ml-4 list-disc">{c.lessons.map((l: any) => (
                <li key={l.id}><Link href={`/cours/${l.id}`} className={lien}>{l.title}</Link>{ok.has(l.id) && <span className="text-succes-600"> ✓ terminée</span>}</li>))}</ul></div>))}
          </section>); })}
    </main></>);
}
