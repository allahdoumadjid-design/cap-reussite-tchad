import { notFound } from "next/navigation";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { requireProfil } from "@/lib/auth";
import Entete from "@/components/Entete";

// Contenu : { "sections": [ { "type": "objectifs|definition|formule|exemple|erreur|resume|texte", "titre": "...", "texte": "..." } ] }
type Section = { type?: string; titre: string; texte: string };
const style: Record<string, string> = {
  objectifs: "border-l-4 border-marine-600 bg-marine-50 p-4",
  definition: "border-l-4 border-marine-800 bg-slate-50 p-4",
  exemple: "border-l-4 border-succes-500 bg-green-50 p-4",
  erreur: "border-l-4 border-action-500 bg-orange-50 p-4",
  resume: "border-l-4 border-succes-600 bg-green-50 p-4",
};

export default async function Lecon({ params }: { params: { id: string } }) {
  const profil = await requireProfil();
  const supabase = createClient();
  const { data: lecon } = await supabase.from("lessons").select("id, title, content").eq("id", params.id).maybeSingle();
  if (!lecon) notFound();
  await supabase.from("student_progress").upsert(
    { student_id: profil.id, lesson_id: lecon.id, last_viewed_at: new Date().toISOString() }, { onConflict: "student_id,lesson_id" });
  const [{ data: prog }, { data: fav }, { data: res }] = await Promise.all([
    supabase.from("student_progress").select("completed").eq("student_id", profil.id).eq("lesson_id", lecon.id).maybeSingle(),
    supabase.from("student_favorites").select("lesson_id").eq("student_id", profil.id).eq("lesson_id", lecon.id).maybeSingle(),
    supabase.from("lesson_resources").select("id, title, file_path").eq("lesson_id", lecon.id),
  ]);
  const documents = (await Promise.all((res ?? []).map(async (r: any) => {
    const { data } = await supabase.storage.from("ressources").createSignedUrl(r.file_path, 300);
    return data?.signedUrl ? { id: r.id, title: r.title, url: data.signedUrl } : null;
  }))).filter(Boolean) as { id: string; title: string; url: string }[];

  async function basculerTerminee() {
    "use server";
    const p = await requireProfil();
    await createClient().from("student_progress").upsert(
      { student_id: p.id, lesson_id: params.id, completed: !prog?.completed }, { onConflict: "student_id,lesson_id" });
    revalidatePath(`/cours/${params.id}`);
  }
  async function basculerFavori() {
    "use server";
    const p = await requireProfil(); const sb = createClient();
    if (fav) await sb.from("student_favorites").delete().eq("student_id", p.id).eq("lesson_id", params.id);
    else await sb.from("student_favorites").insert({ student_id: p.id, lesson_id: params.id });
    revalidatePath(`/cours/${params.id}`);
  }
  const sections: Section[] = lecon.content?.sections ?? [];
  return (<><Entete profil={profil} />
    <main id="contenu" className="mx-auto max-w-3xl space-y-6 px-4 py-8">
      <h1 className="text-3xl font-bold text-marine-900">{lecon.title}</h1>
      {sections.length === 0 && <p>Le contenu de cette leçon n'a pas encore été rédigé.</p>}
      {sections.map((s, i) => (<section key={i} className={style[s.type ?? ""] ?? ""}>
        <h2 className="text-xl font-semibold text-marine-800">{s.titre}</h2>
        {s.type === "formule"
          ? <pre className="mt-2 overflow-x-auto rounded bg-slate-100 p-3 font-mono text-lg">{s.texte}</pre>
          : <p className="mt-2 whitespace-pre-line leading-relaxed">{s.texte}</p>}
      </section>))}
      {documents.length > 0 && (<section aria-labelledby="docs"><h2 id="docs" className="text-xl font-semibold text-marine-800">Documents à télécharger</h2>
        <ul className="mt-2 list-disc pl-5">{documents.map((d) => (<li key={d.id}><a href={d.url} className="text-marine-600 underline">{d.title}</a></li>))}</ul></section>)}
      <div className="flex flex-wrap gap-3">
        <form action={basculerTerminee}><button className={"rounded px-4 py-2 font-semibold " + (prog?.completed ? "bg-slate-200" : "bg-succes-500 text-white")}>
          {prog?.completed ? "Marquer comme non terminée" : "Marquer comme terminée"}</button></form>
        <form action={basculerFavori}><button className="rounded border border-marine-800 px-4 py-2 font-semibold text-marine-800">
          {fav ? "Retirer des favoris" : "Ajouter aux favoris"}</button></form>
      </div>
    </main></>);
}
