"use client";
export default function Erreur({ reset }: { error: Error; reset: () => void }) {
  return (<main id="contenu" role="alert" className="mx-auto flex min-h-screen max-w-xl flex-col justify-center gap-4 px-6 text-center">
    <h1 className="text-2xl font-bold text-marine-900">Un problème est survenu</h1>
    <p className="text-slate-700">Ce n'est pas de votre faute. Vérifiez votre connexion puis réessayez.</p>
    <div><button onClick={reset} className="rounded-lg bg-action-500 px-5 py-2.5 font-semibold text-marine-900">Réessayer</button></div>
  </main>);
}
