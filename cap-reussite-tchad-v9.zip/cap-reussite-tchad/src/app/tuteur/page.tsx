import Link from "next/link";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { requireProfil } from "@/lib/auth";
import { lireConfigIA } from "@/lib/tuteur";
import Entete from "@/components/Entete";
import Tuteur from "@/components/Tuteur";
import BoutonConfirmer from "@/components/BoutonConfirmer";

async function supprimer(f: FormData) {
  "use server";
  const p = await requireProfil();
  const id = String(f.get("id") ?? "");
  await createClient().from("ai_conversations").delete().eq("id", id).eq("student_id", p.id);
  revalidatePath("/tuteur"); redirect("/tuteur");
}

export default async function PageTuteur({ searchParams }: { searchParams: { c?: string } }) {
  const profil = await requireProfil();
  const cfg = lireConfigIA(process.env);
  const supabase = createClient();
  const { data: convs } = await supabase.from("ai_conversations").select("id, title, mode, created_at").order("created_at", { ascending: false }).limit(10);
  const courante = (convs ?? []).find((c: any) => c.id === searchParams.c);
  const { data: anciens } = courante
    ? await supabase.from("ai_messages").select("role, content").eq("conversation_id", courante.id).order("id")
    : { data: [] as any[] };
  return (<><Entete profil={profil} />
    <main id="contenu" className="mx-auto max-w-3xl space-y-6 px-4 py-8">
      <h1 className="text-3xl font-bold text-marine-900">Tuteur IA</h1>
      {!profil.is_active ? <p>Votre compte doit être activé pour utiliser le tuteur.</p>
        : !cfg || !process.env.SUPABASE_SERVICE_ROLE_KEY ? (
          <section className="rounded-lg border-l-4 border-action-500 bg-orange-50 p-4">
            <h2 className="font-semibold">Le tuteur IA n'est pas encore activé</h2>
            <p className="mt-1">L'interface est prête, mais aucun service d'IA n'est configuré sur cette plateforme. Un administrateur doit renseigner les variables <code>AI_PROVIDER</code>, <code>AI_API_KEY</code> et <code>AI_MODEL</code> (voir le README), puis tester une conversation.</p>
          </section>) : (<>
          <p className="rounded bg-marine-50 p-3 text-sm">Vos messages sont envoyés à un service d'IA externe pour obtenir une réponse. Ils sont conservés dans votre historique, visible par vous seul dans l'application, et vous pouvez les supprimer. Ne saisissez pas d'informations personnelles (téléphone, adresse…). Limite : {cfg.limiteJour} questions par jour.</p>
          <Tuteur key={courante?.id ?? "nouvelle"} initial={(anciens ?? []) as any} conversationId={courante?.id} modeInitial={courante?.mode} />
          <section aria-labelledby="hist" className="space-y-2"><div className="flex items-center justify-between"><h2 id="hist" className="text-xl font-semibold">Mes conversations</h2>
            <Link href="/tuteur" className="text-marine-600 underline">Nouvelle conversation</Link></div>
            {(convs ?? []).length === 0 ? <p>Aucune conversation.</p> : <ul className="space-y-1">{(convs ?? []).map((c: any) => (<li key={c.id} className="flex items-center gap-3">
              <Link href={`/tuteur?c=${c.id}`} className="text-marine-600 underline">{c.title}</Link>
              <span className="text-sm text-slate-700">{new Date(c.created_at).toLocaleDateString("fr-FR")}</span>
              <form action={supprimer}><input type="hidden" name="id" value={c.id} /><BoutonConfirmer message="Supprimer cette conversation ?" className="text-sm text-red-700 underline">Supprimer</BoutonConfirmer></form></li>))}</ul>}
          </section></>)}
    </main></>);
}
