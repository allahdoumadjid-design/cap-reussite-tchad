import type { MetadataRoute } from "next";
export default function robots(): MetadataRoute.Robots {
  return { rules: { userAgent: "*", allow: "/", disallow: ["/admin", "/api", "/tableau-de-bord", "/cours", "/tuteur", "/quiz", "/tentative", "/historique", "/entrainement", "/bac"] } };
}
