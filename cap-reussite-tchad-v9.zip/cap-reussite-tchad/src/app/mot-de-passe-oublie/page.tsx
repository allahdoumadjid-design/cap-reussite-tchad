"use client";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";

export default function MotDePasseOublie() {
  const [envoye, setEnvoye] = useState(false);
  const [chargement, setChargement] = useState(false);
  async function envoyer(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setChargement(true);
    const email = String(new FormData(e.currentTarget).get("email"));
    await createClient().auth.resetPasswordForEmail(email, {
      redirectTo: `${location.origin}/auth/callback?next=/nouveau-mot-de-passe`,
    });
    setEnvoye(true); setChargement(false); // message identique, que le compte existe ou non
  }
  return (<main id="contenu" className="mx-auto max-w-md px-6 py-16">
    <h1 className="mb-6 text-2xl font-bold text-marine-900">Mot de passe oublié</h1>
    {envoye ? <p role="status">Si un compte existe pour cette adresse, un lien de réinitialisation vient d'être envoyé. Vérifiez votre boîte de réception.</p> : (
      <form onSubmit={envoyer} className="space-y-4">
        <div><label htmlFor="email" className="mb-1 block font-medium">Adresse e-mail</label>
          <input id="email" name="email" type="email" required autoComplete="email" className="w-full rounded border border-slate-400 px-3 py-2" /></div>
        <button disabled={chargement} className="w-full rounded bg-action-500 px-4 py-2 font-semibold text-marine-900 disabled:opacity-60">
          {chargement ? "Envoi…" : "Envoyer le lien"}</button>
      </form>)}
  </main>);
}
