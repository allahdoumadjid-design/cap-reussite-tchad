import type { Metadata, Viewport } from "next";
import "./globals.css";

const site = process.env.NEXT_PUBLIC_SITE_URL ?? (process.env.VERCEL_PROJECT_PRODUCTION_URL ? `https://${process.env.VERCEL_PROJECT_PRODUCTION_URL}` : "http://localhost:3000");

export const metadata: Metadata = {
  metadataBase: new URL(site),
  title: { default: "CAP RÉUSSITE TCHAD", template: "%s | CAP RÉUSSITE TCHAD" },
  description: "Plateforme éducative pour les élèves du secondaire au Tchad : cours, exercices corrigés, quiz, examens blancs, révisions et tuteur IA.",
  openGraph: { title: "CAP RÉUSSITE TCHAD", description: "Comprendre simplement. Apprendre durablement. Réussir avec confiance.", locale: "fr_FR", type: "website" },
};
export const viewport: Viewport = { width: "device-width", initialScale: 1, themeColor: "#0f2e5c" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <body className="min-h-screen bg-white font-sans text-slate-900 antialiased">
        <a href="#contenu" className="sr-only focus:not-sr-only focus:absolute focus:left-2 focus:top-2 focus:z-50 focus:rounded focus:bg-white focus:px-3 focus:py-2 focus:font-semibold">Aller au contenu</a>
        {children}
      </body>
    </html>
  );
}
