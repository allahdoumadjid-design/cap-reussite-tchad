export default function Chargement() {
  return (<div role="status" aria-live="polite" className="mx-auto max-w-3xl space-y-4 px-4 py-16">
    <span className="sr-only">Chargement…</span>
    <div className="h-8 w-2/3 animate-pulse rounded bg-slate-200 motion-reduce:animate-none" />
    <div className="h-4 w-full animate-pulse rounded bg-slate-200 motion-reduce:animate-none" />
    <div className="h-4 w-5/6 animate-pulse rounded bg-slate-200 motion-reduce:animate-none" />
  </div>);
}
