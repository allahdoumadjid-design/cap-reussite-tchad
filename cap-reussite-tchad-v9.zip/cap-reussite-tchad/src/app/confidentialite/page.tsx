import type { Metadata } from "next";
import EntetePublic from "@/components/EntetePublic";
import PiedDePage from "@/components/PiedDePage";

export const metadata: Metadata = { title: "Confidentialité et données personnelles" };

export default function Confidentialite() {
  return (
    <>
      <EntetePublic />
      <main id="contenu" className="mx-auto max-w-3xl space-y-6 px-4 py-12 leading-relaxed">
        <h1 className="text-3xl font-bold text-marine-900">Confidentialité et données personnelles</h1>
        <p className="rounded border-l-4 border-action-500 bg-orange-50 p-3 text-sm"><strong>Version provisoire.</strong> Ce texte doit être relu et complété par le responsable du projet avant l'ouverture aux élèves : adresse de contact, durées de conservation et cadre légal applicable au Tchad.</p>
        <h2 className="text-xl font-semibold text-marine-800">Données que nous traitons</h2>
        <p>Votre nom d'affichage, votre adresse e-mail, votre classe et votre établissement, votre progression dans les cours, vos réponses aux exercices et quiz, vos favoris, et, si vous utilisez le tuteur IA, vos messages et ses réponses.</p>
        <h2 className="text-xl font-semibold text-marine-800">À quoi elles servent</h2>
        <p>À gérer votre compte, afficher votre progression, corriger vos évaluations et vous proposer des révisions adaptées. Elles ne servent ni à la publicité ni à la vente.</p>
        <h2 className="text-xl font-semibold text-marine-800">Qui y a accès</h2>
        <p>Vos résultats et votre progression sont visibles de vous et des administrateurs de la plateforme. Vos conversations avec le tuteur IA sont visibles de vous seul dans l'application et peuvent être supprimées par vous.</p>
        <h2 className="text-xl font-semibold text-marine-800">Prestataires techniques</h2>
        <p>Les données sont hébergées chez des prestataires techniques (base de données et authentification, hébergement du site). Lorsque le tuteur IA est activé, le texte de vos messages est transmis à un fournisseur de service d'IA pour produire la réponse. Ne saisissez pas d'informations personnelles (téléphone, adresse) dans le tuteur.</p>
        <h2 className="text-xl font-semibold text-marine-800">Élèves mineurs</h2>
        <p>Les élèves sont souvent mineurs. Les parents ou tuteurs légaux doivent être informés de l'utilisation de la plateforme.</p>
        <h2 className="text-xl font-semibold text-marine-800">Vos droits</h2>
        <p>Vous pouvez demander à l'administrateur de consulter, corriger ou supprimer vos données, ou de supprimer votre compte.</p>
        <h2 className="text-xl font-semibold text-marine-800">Sécurité</h2>
        <p>Les mots de passe ne sont jamais stockés en clair et chaque élève n'accède qu'à ses propres données privées. Aucun système n'est parfaitement sûr : en cas de doute, prévenez l'administrateur.</p>
      </main>
      <PiedDePage />
    </>
  );
}
