import Link from "next/link";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { requireAdmin } from "@/lib/auth";
import Message from "@/components/Message";
import BoutonConfirmer from "@/components/BoutonConfirmer";
import { aller, btn, btnDanger, champ, estUuid } from "@/lib/admin";

const KINDS: Record<string, string> = { exercise: "Exercice", lesson_quiz: "Quiz de leçon", chapter_quiz: "Quiz de chapitre",
  subject_eval: "Évaluation de matière", bac_blanc: "Examen blanc", bac_topic: "Entraînement par thème" };
const PAGE = "/admin/quiz";

async function agir(f: FormData) {
  "use server";
  await requireAdmin();
  const sb = createClient();
  const v = (k: string) => String(f.get(k) ?? "").trim();
  const op = v("op"), id = v("id");
  if (op === "creer") {
    const titre = v("titre"), minutes = v("minutes");
    if (titre.length < 2 || titre.length > 160) aller(PAGE, "erreur", "Le titre doit contenir entre 2 et 160 caractères.");
    if (!estUuid(v("class_id")) || !(v("kind") in KINDS)) aller(PAGE, "erreur", "Classe ou type invalide.");
    const duree = minutes ? Number(minutes) : null;
    if (duree !== null && (!Number.isInteger(duree) || duree < 1 || duree > 360)) aller(PAGE, "erreur", "Durée : entre 1 et 360 minutes.");
    const { data, error } = await sb.from("quizzes").insert({ class_id: v("class_id"), kind: v("kind"), title: titre, time_limit_minutes: duree,
      is_official: f.get("officiel") === "on", source_note: v("source") || null }).select("id").single();
    if (error || !data) aller(PAGE, "erreur", "Création impossible.");
    aller(`${PAGE}/${data.id}`, "ok", "Évaluation créée (brouillon). Ajoutez des questions.");
  }
  if (!estUuid(id)) aller(PAGE, "erreur", "Évaluation invalide.");
  if (op === "pub") {
    const publier = v("publier") === "1";
    if (publier) { const { count } = await sb.from("quiz_questions").select("id", { count: "exact", head: true }).eq("quiz_id", id);
      if (!count) aller(PAGE, "erreur", "Ajoutez au moins une question avant de publier."); }
    await sb.from("quizzes").update({ is_published: publier }).eq("id", id);
  } else if (op === "suppr") await sb.from("quizzes").delete().eq("id", id);
  revalidatePath(PAGE); aller(PAGE, "ok", "Enregistré.");
}

export default async function Quiz({ searchParams }: { searchParams: { ok?: string; erreur?: string } }) {
  await requireAdmin();
  const sb = createClient();
  const { data: quiz } = await sb.from("quizzes").select("id, title, kind, is_published, is_official, classes(name)").order("created_at", { ascending: false });
  const { data: classes } = await sb.from("classes").select("id, name").order("sort_order");
  return (<main id="contenu" className="mx-auto max-w-5xl space-y-6 px-4 py-8">
    <h1 className="text-3xl font-bold text-marine-900">Quiz et examens</h1>
    <Message ok={searchParams.ok} erreur={searchParams.erreur} />
    <section className="rounded-lg border p-4"><h2 className="mb-3 text-xl font-semibold">Nouvelle évaluation</h2>
      <form action={agir} className="grid gap-3 sm:grid-cols-2"><input type="hidden" name="op" value="creer" />
        <div className="sm:col-span-2"><label htmlFor="titre" className="mb-1 block">Titre</label><input id="titre" name="titre" required minLength={2} maxLength={160} className={champ} /></div>
        <div><label htmlFor="class_id" className="mb-1 block">Classe</label><select id="class_id" name="class_id" required className={champ}>{(classes ?? []).map((c: any) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></div>
        <div><label htmlFor="kind" className="mb-1 block">Type</label><select id="kind" name="kind" className={champ}>{Object.entries(KINDS).map(([k, n]) => <option key={k} value={k}>{n}</option>)}</select></div>
        <div><label htmlFor="minutes" className="mb-1 block">Durée en minutes (facultatif)</label><input id="minutes" name="minutes" inputMode="numeric" className={champ} /></div>
        <div><label htmlFor="source" className="mb-1 block">Source ou remarque (facultatif)</label><input id="source" name="source" maxLength={200} className={champ} /></div>
        <label className="flex items-center gap-2 sm:col-span-2"><input type="checkbox" name="officiel" /> Sujet officiel dont j'ai vérifié l'authenticité</label>
        <div><button className={btn}>Créer</button></div>
      </form></section>
    {(quiz ?? []).length === 0 ? <p>Aucune évaluation.</p> : <ul className="space-y-3">{(quiz ?? []).map((z: any) => (
      <li key={z.id} className="flex flex-wrap items-center gap-3 rounded-lg border p-4">
        <Link href={`/admin/quiz/${z.id}`} className="font-semibold text-marine-600 underline">{z.title}</Link>
        <span className="text-sm text-slate-700">{KINDS[z.kind]} · {z.classes?.name} · {z.is_published ? "publiée" : "brouillon"}{z.is_official ? " · officiel vérifié" : ""}</span>
        <form action={agir} className="ml-auto flex gap-2"><input type="hidden" name="id" value={z.id} />
          <input type="hidden" name="op" value="pub" /><input type="hidden" name="publier" value={z.is_published ? "0" : "1"} />
          <button className={btn}>{z.is_published ? "Dépublier" : "Publier"}</button></form>
        <form action={agir}><input type="hidden" name="id" value={z.id} /><input type="hidden" name="op" value="suppr" />
          <BoutonConfirmer message={`Supprimer « ${z.title} » avec ses questions et toutes les tentatives des élèves ?`} className={btnDanger}>Supprimer</BoutonConfirmer></form>
      </li>))}</ul>}
  </main>);
}
