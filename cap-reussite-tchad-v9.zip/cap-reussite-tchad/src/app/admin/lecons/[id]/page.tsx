import Link from "next/link";
import { notFound } from "next/navigation";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { requireAdmin } from "@/lib/auth";
import Message from "@/components/Message";
import BoutonConfirmer from "@/components/BoutonConfirmer";
import { aller, btn, btnDanger, champ, ecrireSections, estUuid, lireSections } from "@/lib/admin";

const TYPES_AUTORISES = ["application/pdf", "image/png", "image/jpeg",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "application/vnd.openxmlformats-officedocument.presentationml.presentation"];

async function agir(f: FormData) {
  "use server";
  await requireAdmin();
  const sb = createClient();
  const v = (k: string) => String(f.get(k) ?? "");
  const op = v("op"), id = v("id"), page = `/admin/lecons/${id}`;
  if (!estUuid(id)) aller("/admin/contenus", "erreur", "Leçon invalide.");
  if (op === "sauver") {
    const titre = v("titre").trim();
    if (titre.length < 2 || titre.length > 120) aller(page, "erreur", "Le titre doit contenir entre 2 et 120 caractères.");
    const sections = lireSections(v("contenu").slice(0, 60000));
    const { error } = await sb.from("lessons").update({ title: titre, content: { sections }, is_published: f.get("publie") === "on", updated_at: new Date().toISOString() }).eq("id", id);
    if (error) aller(page, "erreur", "Enregistrement impossible.");
    revalidatePath(page); aller(page, "ok", `Leçon enregistrée (${sections.length} section(s)).`);
  }
  if (op === "televerser") {
    const fichier = f.get("fichier") as File | null;
    const titre = v("titre_doc").trim() || fichier?.name || "Document";
    if (!fichier || fichier.size === 0) aller(page, "erreur", "Choisissez un fichier.");
    if (fichier.size > 10 * 1024 * 1024) aller(page, "erreur", "Fichier trop lourd (10 Mo maximum).");
    if (!TYPES_AUTORISES.includes(fichier.type)) aller(page, "erreur", "Type non autorisé (PDF, PNG, JPEG, Word ou PowerPoint).");
    const sur = fichier.name.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-zA-Z0-9._-]/g, "_").slice(-80);
    const chemin = `${id}/${crypto.randomUUID()}-${sur}`;
    const { error: e1 } = await sb.storage.from("ressources").upload(chemin, fichier, { contentType: fichier.type });
    if (e1) aller(page, "erreur", "Le téléversement a échoué.");
    const { error: e2 } = await sb.from("lesson_resources").insert({ lesson_id: id, title: titre.slice(0, 120), file_path: chemin, mime_type: fichier.type, size_bytes: fichier.size });
    if (e2) { await sb.storage.from("ressources").remove([chemin]); aller(page, "erreur", "Le document n'a pas pu être enregistré."); }
    revalidatePath(page); aller(page, "ok", "Document ajouté.");
  }
  if (op === "suppr_doc") {
    const rid = v("rid");
    if (!estUuid(rid)) aller(page, "erreur", "Document invalide.");
    const { data: r } = await sb.from("lesson_resources").select("file_path").eq("id", rid).eq("lesson_id", id).maybeSingle();
    if (r) await sb.storage.from("ressources").remove([r.file_path]);
    await sb.from("lesson_resources").delete().eq("id", rid).eq("lesson_id", id);
    revalidatePath(page); aller(page, "ok", "Document supprimé.");
  }
  aller(page, "erreur", "Action inconnue.");
}

export default async function EditerLecon({ params, searchParams }: { params: { id: string }; searchParams: { ok?: string; erreur?: string } }) {
  await requireAdmin();
  if (!estUuid(params.id)) notFound();
  const sb = createClient();
  const { data: l } = await sb.from("lessons").select("id, title, content, is_published").eq("id", params.id).maybeSingle();
  if (!l) notFound();
  const { data: docs } = await sb.from("lesson_resources").select("id, title, size_bytes").eq("lesson_id", l.id);
  return (<main id="contenu" className="mx-auto max-w-3xl space-y-6 px-4 py-8">
    <Link href="/admin/contenus" className="text-marine-600 underline">← Retour aux cours</Link>
    <h1 className="text-3xl font-bold text-marine-900">Modifier la leçon</h1>
    <Message ok={searchParams.ok} erreur={searchParams.erreur} />
    <form action={agir} className="space-y-4">
      <input type="hidden" name="op" value="sauver" /><input type="hidden" name="id" value={l.id} />
      <div><label htmlFor="titre" className="mb-1 block font-medium">Titre</label><input id="titre" name="titre" defaultValue={l.title} required minLength={2} maxLength={120} className={champ} /></div>
      <div><label htmlFor="contenu" className="mb-1 block font-medium">Contenu</label>
        <p className="mb-1 text-sm text-slate-700">Chaque section commence par <code>## type | Titre</code>. Types : objectifs, definition, formule, exemple, erreur, resume, texte. Exemple : <code>## definition | Dérivée</code> puis le texte.</p>
        <textarea id="contenu" name="contenu" rows={18} defaultValue={ecrireSections(l.content?.sections ?? [])} className={champ + " font-mono text-sm"} /></div>
      <label className="flex items-center gap-2"><input type="checkbox" name="publie" defaultChecked={l.is_published} /> Publiée (visible des élèves)</label>
      <button className={btn}>Enregistrer la leçon</button>
    </form>
    <section aria-labelledby="docs" className="space-y-3 rounded-lg border p-4">
      <h2 id="docs" className="text-xl font-semibold">Documents téléchargeables</h2>
      {(docs ?? []).length === 0 && <p>Aucun document.</p>}
      <ul className="space-y-2">{(docs ?? []).map((d: any) => (<li key={d.id} className="flex flex-wrap items-center gap-3">
        <span>{d.title}{d.size_bytes ? ` (${Math.round(d.size_bytes / 1024)} Ko)` : ""}</span>
        <form action={agir}><input type="hidden" name="op" value="suppr_doc" /><input type="hidden" name="id" value={l.id} /><input type="hidden" name="rid" value={d.id} />
          <BoutonConfirmer message={`Supprimer « ${d.title} » ?`} className={btnDanger}>Supprimer</BoutonConfirmer></form></li>))}</ul>
      <form action={agir} className="space-y-3">
        <input type="hidden" name="op" value="televerser" /><input type="hidden" name="id" value={l.id} />
        <div><label htmlFor="titre_doc" className="mb-1 block">Titre du document</label><input id="titre_doc" name="titre_doc" maxLength={120} className={champ} /></div>
        <div><label htmlFor="fichier" className="mb-1 block">Fichier (PDF, image, Word ou PowerPoint, 10 Mo max)</label><input id="fichier" name="fichier" type="file" required /></div>
        <button className={btn}>Téléverser</button>
      </form>
    </section>
  </main>);
}
