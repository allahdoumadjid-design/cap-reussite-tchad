import Link from "next/link";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { requireAdmin } from "@/lib/auth";
import Message from "@/components/Message";
import BoutonConfirmer from "@/components/BoutonConfirmer";
import { aller, btn, btnDanger, champ, estUuid } from "@/lib/admin";

const CH = "/admin/contenus";

async function agir(f: FormData) {
  "use server";
  await requireAdmin();
  const sb = createClient();
  const v = (k: string) => String(f.get(k) ?? "").trim();
  const op = v("op"), id = v("id"), titre = v("titre");
  if (["classe", "matiere", "chapitre", "lecon"].includes(op) && (titre.length < 2 || titre.length > 120))
    aller(CH, "erreur", "Le titre doit contenir entre 2 et 120 caractères.");
  if (op !== "classe" && !estUuid(id)) aller(CH, "erreur", "Élément invalide.");
  let res: { error: unknown } = { error: null }; let nouvelle: string | null = null;
  if (op === "classe") res = await sb.from("classes").insert({ name: titre, level: v("niveau") || "Lycée", sort_order: 100 });
  else if (op === "matiere") res = await sb.from("subjects").insert({ class_id: id, name: titre });
  else if (op === "chapitre") res = await sb.from("chapters").insert({ subject_id: id, title: titre });
  else if (op === "lecon") { const r = await sb.from("lessons").insert({ chapter_id: id, title: titre }).select("id").single(); res = r; nouvelle = r.data?.id ?? null; }
  else if (op === "suppr_matiere") res = await sb.from("subjects").delete().eq("id", id);
  else if (op === "suppr_chapitre") res = await sb.from("chapters").delete().eq("id", id);
  else if (op === "suppr_lecon") res = await sb.from("lessons").delete().eq("id", id);
  else if (op === "pub_chapitre") res = await sb.from("chapters").update({ is_published: v("publier") === "1" }).eq("id", id);
  else if (op === "pub_lecon") res = await sb.from("lessons").update({ is_published: v("publier") === "1" }).eq("id", id);
  else aller(CH, "erreur", "Action inconnue.");
  if (res.error) aller(CH, "erreur", "L'opération a échoué (ce nom existe peut-être déjà).");
  if (nouvelle) aller(`/admin/lecons/${nouvelle}`, "ok", "Leçon créée. Rédigez son contenu.");
  revalidatePath(CH); aller(CH, "ok", "Enregistré.");
}

function Cache({ op, id, extra }: { op: string; id?: string; extra?: Record<string, string> }) {
  return <>{<input type="hidden" name="op" value={op} />}{id && <input type="hidden" name="id" value={id} />}
    {Object.entries(extra ?? {}).map(([k, val]) => <input key={k} type="hidden" name={k} value={val} />)}</>;
}
function Publier({ op, id, publie }: { op: string; id: string; publie: boolean }) {
  return <form action={agir} className="inline"><Cache op={op} id={id} extra={{ publier: publie ? "0" : "1" }} />
    <button className="text-sm text-marine-600 underline">{publie ? "Dépublier" : "Publier"}</button></form>;
}
function Suppr({ op, id, message }: { op: string; id: string; message: string }) {
  return <form action={agir} className="inline"><Cache op={op} id={id} /><BoutonConfirmer message={message} className="text-sm text-red-700 underline">Supprimer</BoutonConfirmer></form>;
}
function Ajout({ op, id, label }: { op: string; id?: string; label: string }) {
  return <form action={agir} className="mt-2 flex flex-wrap items-end gap-2"><Cache op={op} id={id} />
    <div><label className="mb-1 block text-sm">{label}</label><input name="titre" required minLength={2} maxLength={120} className={champ} /></div>
    <button className={btn}>Ajouter</button></form>;
}

export default async function Contenus({ searchParams }: { searchParams: { ok?: string; erreur?: string } }) {
  await requireAdmin();
  const { data: classes } = await createClient().from("classes")
    .select("id, name, is_provisional, subjects(id, name, sort_order, chapters(id, title, sort_order, is_published, lessons(id, title, sort_order, is_published)))").order("sort_order");
  const tri = (a: any, b: any) => a.sort_order - b.sort_order;
  return (<main id="contenu" className="mx-auto max-w-5xl space-y-6 px-4 py-8">
    <h1 className="text-3xl font-bold text-marine-900">Gestion des cours</h1>
    <Message ok={searchParams.ok} erreur={searchParams.erreur} />
    <p className="text-sm text-slate-700">Un chapitre ou une leçon n'est visible des élèves qu'une fois publié. Les classes marquées « provisoire » ne sont pas validées avec une source officielle.</p>
    {(classes ?? []).map((c: any) => (<section key={c.id} className="space-y-3 rounded-lg border p-4">
      <h2 className="text-xl font-semibold text-marine-800">{c.name}{c.is_provisional && <span className="text-sm font-normal text-orange-800"> (structure provisoire)</span>}</h2>
      {[...(c.subjects ?? [])].sort(tri).map((m: any) => (<div key={m.id} className="ml-2 border-l-2 pl-4">
        <h3 className="font-semibold">{m.name} <Suppr op="suppr_matiere" id={m.id} message={`Supprimer la matière « ${m.name} » et tous ses chapitres, leçons et progrès associés ?`} /></h3>
        {[...(m.chapters ?? [])].sort(tri).map((ch: any) => (<div key={ch.id} className="ml-3 mt-2">
          <p className="font-medium">{ch.title} <span className="text-sm text-slate-700">({ch.is_published ? "publié" : "brouillon"})</span>{" "}
            <Publier op="pub_chapitre" id={ch.id} publie={ch.is_published} />{" "}
            <Suppr op="suppr_chapitre" id={ch.id} message={`Supprimer le chapitre « ${ch.title} » et ses leçons ?`} /></p>
          <ul className="ml-4 list-disc">{[...(ch.lessons ?? [])].sort(tri).map((l: any) => (<li key={l.id}>
            <Link href={`/admin/lecons/${l.id}`} className="text-marine-600 underline">{l.title}</Link>
            <span className="text-sm text-slate-700"> ({l.is_published ? "publiée" : "brouillon"})</span>{" "}
            <Publier op="pub_lecon" id={l.id} publie={l.is_published} />{" "}
            <Suppr op="suppr_lecon" id={l.id} message={`Supprimer la leçon « ${l.title} » ?`} /></li>))}</ul>
          <Ajout op="lecon" id={ch.id} label="Nouvelle leçon" />
        </div>))}
        <Ajout op="chapitre" id={m.id} label="Nouveau chapitre" />
      </div>))}
      <Ajout op="matiere" id={c.id} label={`Nouvelle matière en ${c.name}`} />
    </section>))}
    <section className="rounded-lg border p-4"><h2 className="text-xl font-semibold">Nouvelle classe</h2><Ajout op="classe" label="Nom de la classe" /></section>
  </main>);
}
