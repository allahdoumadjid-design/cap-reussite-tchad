import Link from "next/link";
import EntetePublic from "@/components/EntetePublic";
import PiedDePage from "@/components/PiedDePage";
import Icone from "@/components/Icone";

function Section({ id, titre, intro, fond, children }: { id: string; titre: string; intro?: string; fond?: boolean; children: React.ReactNode }) {
  return (
    <section id={id} aria-labelledby={id + "-t"} className={"scroll-mt-16 " + (fond ? "bg-marine-50" : "bg-white")}>
      <div className="mx-auto max-w-6xl px-4 py-16 sm:py-20">
        <h2 id={id + "-t"} className="text-3xl font-bold tracking-tight text-marine-900 sm:text-4xl">{titre}</h2>
        {intro && <p className="mt-3 max-w-3xl text-lg text-slate-700">{intro}</p>}
        <div className="mt-10">{children}</div>
      </div>
    </section>
  );
}

const couleurs: Record<string, string> = { bleu: "bg-marine-50 text-marine-600", orange: "bg-orange-100 text-action-600", vert: "bg-green-100 text-succes-600" };
function Carte({ icone, titre, texte, couleur = "bleu" }: { icone: string; titre: string; texte: string; couleur?: string }) {
  return (
    <li className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md motion-reduce:transform-none">
      <span className={"inline-flex h-11 w-11 items-center justify-center rounded-xl " + couleurs[couleur]}><Icone nom={icone} /></span>
      <h3 className="mt-4 text-lg font-semibold text-marine-900">{titre}</h3>
      <p className="mt-2 text-slate-700">{texte}</p>
    </li>
  );
}

const avantages = [
  ["livre", "Des cours clairs et organisés", "Chaque cours suit la même structure : objectifs, explications, exemples résolus, erreurs fréquentes et résumé. Classe, matière, chapitre, leçon : on trouve vite ce que l'on cherche.", "bleu"],
  ["check", "Des exercices corrigés pas à pas", "La correction explique le raisonnement, pas seulement le résultat. On peut refaire un exercice autant de fois que nécessaire.", "vert"],
  ["graphique", "Une progression visible", "Chapitres terminés, derniers résultats, notions fortes et notions à retravailler : tout est calculé à partir de votre travail réel.", "orange"],
  ["etincelle", "Un tuteur IA pédagogique", "Il explique avec des mots simples, guide étape par étape et pose des questions. Il encourage le raisonnement au lieu de donner seulement la réponse.", "bleu"],
  ["telecharger", "Des documents à télécharger", "Fiches de révision et documents en PDF, à garder sur son téléphone pour réviser même avec une connexion lente.", "vert"],
  ["mobile", "Pensé pour le téléphone", "Pages légères, lecture confortable sur petit écran et navigation simple, pour apprendre où que l'on soit.", "orange"],
];
const modes = [
  ["Explique-moi simplement", "Une notion expliquée avec des mots simples, un exemple concret et une progression adaptée à votre classe."],
  ["Résolvons l'exercice ensemble", "Le tuteur vous guide : données utiles, indices, étapes, vérification. La correction complète vient en dernier."],
  ["Interroge-moi", "Des questions adaptées à votre classe et à votre chapitre, avec un bilan à la fin pour savoir quoi retravailler."],
  ["Prépare-moi au bac", "Un programme de révision, des exercices progressifs et des entraînements pour aborder l'examen avec méthode."],
];

export default function Accueil() {
  return (
    <>
      <EntetePublic />
      <main id="contenu">
        {/* Présentation */}
        <section className="relative overflow-hidden bg-gradient-to-br from-marine-900 via-marine-800 to-marine-600 text-white">
          <div className="mx-auto grid max-w-6xl items-center gap-10 px-4 py-16 sm:py-24 md:grid-cols-2">
            <div className="motion-safe:animate-monte">
              <p className="inline-block rounded-full bg-white/10 px-3 py-1 text-sm font-medium">Plateforme éducative pour les élèves du Tchad</p>
              <h1 className="mt-5 text-4xl font-extrabold tracking-tight sm:text-5xl">CAP RÉUSSITE TCHAD</h1>
              <p className="mt-4 text-xl text-white/90 sm:text-2xl">Comprendre simplement. Apprendre durablement. Réussir avec confiance.</p>
              <p className="mt-4 max-w-xl text-white/80">Cours structurés, exercices corrigés, quiz, examens blancs et tuteur intelligent, avec une attention particulière aux filières scientifiques.</p>
              <div className="mt-8 flex flex-wrap gap-3">
                <Link href="/connexion" className="rounded-lg bg-action-500 px-6 py-3 font-semibold text-marine-900 transition hover:bg-white">Se connecter ou demander un accès</Link>
                <Link href="/#fonctionnalites" className="rounded-lg border border-white/50 px-6 py-3 font-semibold transition hover:bg-white/10">Découvrir la plateforme</Link>
              </div>
            </div>
            <div aria-hidden="true" className="hidden grid-cols-3 gap-3 md:grid">
              {["f(x)", "x²", "∑", "√", "π", "∫", "Δ", "sin θ", "H₂O"].map((t, i) => (
                <div key={t} className={"flex aspect-square items-center justify-center rounded-2xl text-2xl font-bold motion-safe:animate-monte " + (i % 4 === 0 ? "bg-action-500 text-marine-900" : i % 4 === 2 ? "bg-succes-500 text-white" : "bg-white/10 text-white")} style={{ animationDelay: `${i * 70}ms` }}>{t}</div>
              ))}
            </div>
          </div>
        </section>

        <Section id="mission" titre="Notre mission" intro="Permettre aux élèves tchadiens de mieux comprendre leurs cours, de s'entraîner régulièrement, de préparer leurs examens et de progresser à leur rythme, grâce à des ressources structurées et à un accompagnement intelligent.">
          <ul className="grid gap-4 sm:grid-cols-3">
            {[["cible", "Comprendre", "Les notions difficiles expliquées simplement.", "bleu"], ["chrono", "S'entraîner", "Exercices, quiz et sessions chronométrées.", "orange"], ["etoile", "Réussir", "Révisions ciblées pour le baccalauréat.", "vert"]].map(([i, t, x, c]) => <Carte key={t} icone={i} titre={t} texte={x} couleur={c} />)}
          </ul>
        </Section>

        <Section id="fonctionnalites" titre="Ce que vous trouverez sur la plateforme" fond>
          <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{avantages.map(([i, t, x, c]) => <Carte key={t} icone={i} titre={t} texte={x} couleur={c} />)}</ul>
        </Section>

        <Section id="fonctionnement" titre="Comment ça marche" intro="L'accès est contrôlé pour protéger les élèves : chaque compte est personnel et validé par l'administrateur.">
          <ol className="grid gap-4 sm:grid-cols-3">
            {[["1", "Demandez un accès", "Remplissez le formulaire de demande avec votre nom et votre adresse e-mail."], ["2", "Le compte est activé", "L'administrateur vérifie votre demande, active votre compte et vous attribue votre classe."], ["3", "Apprenez à votre rythme", "Suivez vos cours, faites les exercices, passez les quiz et suivez vos progrès."]].map(([n, t, x]) => (
              <li key={n} className="rounded-2xl border border-slate-200 p-6">
                <span className="inline-flex h-10 w-10 items-center justify-center rounded-full bg-marine-800 text-lg font-bold text-white">{n}</span>
                <h3 className="mt-4 text-lg font-semibold text-marine-900">{t}</h3><p className="mt-2 text-slate-700">{x}</p></li>))}
          </ol>
        </Section>

        <Section id="matieres" titre="Matières et révisions" intro="Priorité aux matières scientifiques : mathématiques, sciences physiques, sciences de la vie et de la Terre. La liste exacte évolue avec les cours publiés par l'équipe pédagogique." fond>
          <ul className="grid gap-4 sm:grid-cols-3">
            <Carte icone="livre" titre="Cours par classe" texte="Les contenus sont rangés par niveau, classe, matière, chapitre et leçon, et se retrouvent par recherche." couleur="bleu" />
            <Carte icone="telecharger" titre="Fiches et documents" texte="Fiches de révision et documents PDF téléchargeables, associés à chaque leçon." couleur="vert" />
            <Carte icone="chrono" titre="Préparation au baccalauréat" texte="Exercices par thème, examens blancs chronométrés et corrections détaillées. Les sujets d'entraînement sont signalés comme non officiels tant que leur authenticité n'est pas vérifiée." couleur="orange" />
          </ul>
        </Section>

        <Section id="tuteur" titre="Le tuteur IA : quatre façons d'apprendre" intro="Un assistant qui vous aide à comprendre, sans faire le travail à votre place. Il peut se tromper : vérifiez toujours dans votre cours ou avec votre enseignant. Il est activé par l'équipe de la plateforme.">
          <ul className="grid gap-4 sm:grid-cols-2">
            {modes.map(([t, x], i) => <Carte key={t} icone="etincelle" titre={t} texte={x} couleur={["bleu", "orange", "vert", "bleu"][i]} />)}
          </ul>
        </Section>

        <Section id="progression" titre="Suivre sa progression" intro="Chaque élève dispose de son espace personnel : leçons terminées, derniers résultats, points forts, notions à retravailler et prochains objectifs de révision. Rien n'est affiché qui ne vienne de votre travail réel." fond>
          <ul className="grid gap-4 sm:grid-cols-3">
            <Carte icone="graphique" titre="Progression par matière" texte="Une barre de progression pour chaque matière, mise à jour à chaque leçon terminée." couleur="vert" />
            <Carte icone="cible" titre="Notions à retravailler" texte="Après chaque évaluation, le détail des erreurs et les notions à réviser en priorité." couleur="orange" />
            <Carte icone="cadenas" titre="Un espace personnel et privé" texte="Vos résultats et vos conversations ne sont visibles que par vous." couleur="bleu" />
          </ul>
        </Section>

        <section id="acces" aria-labelledby="acces-t" className="scroll-mt-16 bg-marine-900 text-white">
          <div className="mx-auto max-w-4xl px-4 py-16 text-center sm:py-20">
            <h2 id="acces-t" className="text-3xl font-bold sm:text-4xl">Prêt à progresser avec confiance ?</h2>
            <p className="mx-auto mt-3 max-w-2xl text-lg text-white/85">Connectez-vous si vous avez déjà un compte, ou faites une demande d'accès : l'administrateur l'examinera.</p>
            <Link href="/connexion" className="mt-8 inline-flex items-center gap-2 rounded-lg bg-action-500 px-7 py-3 font-semibold text-marine-900 transition hover:bg-white">
              Se connecter ou demander un accès <Icone nom="fleche" className="h-5 w-5" /></Link>
          </div>
        </section>
      </main>
      <PiedDePage />
    </>
  );
}
