import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { requireProfil } from "@/lib/auth";
import Entete from "@/components/Entete";

export default async function Historique() {
  const profil = await requireProfil();
  const supabase = createClient();
  const [{ data: favoris }, { data: histo }] = await Promise.all([
    supabase.from("student_favorites").select("lesson_id, created_at, lessons(title)").eq("student_id", profil.id).order("created_at", { ascending: false }),
    supabase.from("student_progress").select("lesson_id, completed, last_viewed_at, lessons(title)").eq("student_id", profil.id).order("last_viewed_at", { ascending: false }).limit(50),
  ]);
  const lien = "text-marine-600 underline";
  return (<><Entete profil={profil} />
    <main id="contenu" className="mx-auto max-w-3xl space-y-8 px-4 py-8">
      <section aria-labelledby="fav"><h1 id="fav" className="text-3xl font-bold text-marine-900">Mes favoris</h1>
        {(favoris ?? []).length === 0 ? <p className="mt-2">Aucun favori. Ouvrez une leçon et choisissez « Ajouter aux favoris ».</p>
          : <ul className="mt-2 list-disc pl-5">{(favoris ?? []).map((f: any) => <li key={f.lesson_id}><Link href={`/cours/${f.lesson_id}`} className={lien}>{f.lessons?.title}</Link></li>)}</ul>}
      </section>
      <section aria-labelledby="his"><h2 id="his" className="text-2xl font-bold text-marine-900">Historique (50 dernières leçons)</h2>
        {(histo ?? []).length === 0 ? <p className="mt-2">Vous n'avez encore consulté aucune leçon.</p>
          : <ul className="mt-2 space-y-1">{(histo ?? []).map((h: any) => (<li key={h.lesson_id}>
              <Link href={`/cours/${h.lesson_id}`} className={lien}>{h.lessons?.title}</Link>
              <span className="text-sm text-slate-700"> · {new Date(h.last_viewed_at).toLocaleDateString("fr-FR")}</span>{h.completed && <span className="text-succes-600"> ✓</span>}</li>))}</ul>}
      </section>
    </main></>);
}
