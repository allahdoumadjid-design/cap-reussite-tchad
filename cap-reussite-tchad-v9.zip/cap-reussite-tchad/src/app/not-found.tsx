import Link from "next/link";
export default function NonTrouvee() {
  return (<main id="contenu" className="mx-auto flex min-h-screen max-w-xl flex-col justify-center gap-4 px-6 text-center">
    <p className="text-6xl font-extrabold text-action-500">404</p>
    <h1 className="text-2xl font-bold text-marine-900">Cette page n'existe pas</h1>
    <p className="text-slate-700">Le lien est peut-être incorrect ou la page a été déplacée.</p>
    <div><Link href="/" className="inline-block rounded-lg bg-marine-800 px-5 py-2.5 font-semibold text-white">Retour à l'accueil</Link></div>
  </main>);
}
