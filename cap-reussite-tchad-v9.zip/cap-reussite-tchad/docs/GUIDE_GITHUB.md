# Tout terminer depuis GitHub (sans rien installer sur votre ordinateur)

## Méthode recommandée : Codespaces (un ordinateur dans le navigateur)
1. Sur la page du dépôt, cliquez **Add a README file**, puis **Commit changes** (cela crée la branche `main`, nécessaire à Codespaces).
2. Cliquez **Code** > onglet **Codespaces** > **Create codespace on main**. Attendez l'ouverture de l'éditeur.
3. Glissez le fichier `.zip` du projet dans la colonne de gauche (Explorateur). Puis, dans le **Terminal** en bas :
   ```
   unzip cap-reussite-tchad-v9.zip
   cp -r cap-reussite-tchad/. .
   rm -rf cap-reussite-tchad cap-reussite-tchad-v9.zip
   npm install
   ```
4. Vérifiez le projet (chaque commande doit se terminer sans erreur) :
   ```
   npm run typecheck
   npm run lint
   npm test
   npm run build
   ```
   En cas d'erreur, copiez le message complet et envoyez-le-moi : je corrige le fichier concerné.
5. Enregistrez dans GitHub :
   ```
   git add -A
   git commit -m "Plateforme CAP RÉUSSITE TCHAD"
   git push
   ```
   Le fichier `package-lock.json` créé par `npm install` sera envoyé aussi : c'est voulu.
6. Pour voir le site : `cp .env.example .env.local`, remplissez les valeurs Supabase, puis `npm run dev` (Codespaces propose d'ouvrir le port 3000).
7. **Ne publiez jamais `.env.local`** (il est exclu par `.gitignore`).

## Méthode de secours : téléversement par le navigateur
Le projet compte 76 fichiers (moins de 100, limite de GitHub par envoi).
1. Décompressez l'archive sur votre ordinateur.
2. Sur la page du dépôt : **Add file > Upload files**, puis glissez le *contenu* du dossier `cap-reussite-tchad` (pas l'archive). Les dossiers cachés `.github` et `.devcontainer` doivent être inclus : si votre système les masque, activez « afficher les fichiers cachés ».
3. **Commit changes**, puis vérifiez que `.github/workflows/ci.yml`, `.gitignore` et `.env.example` sont présents.
4. L'onglet **Actions** lance les vérifications automatiques. Envoyez-moi les erreurs éventuelles.
Inconvénient : pas de `package-lock.json` ni de test local ; la méthode Codespaces reste préférable.

## Ensuite
Suivez `docs/DEPLOIEMENT.md` (Supabase puis Vercel).
