# État réel de la vérification

## Réellement exécuté (en environnement isolé, sans Internet)
| Contrôle | Résultat |
|---|---|
| `npm test` : 8 tests de la logique du tuteur IA (configuration, validation des entrées, fenêtre d'historique, prompt, erreurs réseau/HTTP/délai, clé absente du corps de requête) | **8 réussis / 0 échec** (après correction d'un test erroné) |
| Typage strict TypeScript de `src/lib/tuteur.ts` | aucune erreur |
| Typage avec résolution des fichiers du projet, **sans** les paquets React/Next/Supabase (non installables ici) | ~1180 messages, tous dus à ces paquets absents ; aucune erreur réelle identifiée à l'examen, mais **ce n'est pas un typage valide** : la CI le fera |
| Contrôle de **syntaxe** de tous les fichiers .ts/.tsx (analyse sans résolution des modules) | 1 erreur trouvée (balise en trop dans `admin/layout.tsx`), corrigée ; 0 erreur au 2e passage. Ce n'est PAS un typage complet. |

## NON exécuté (à faire via la CI GitHub et Supabase)
- `npm install`, `npm run typecheck` sur tout le projet, `npm run lint`, `npm run build`
- Les migrations SQL et `tests/rls_tests.sql` sur une vraie base Supabase
- Tout appel réel au fournisseur d'IA
- Rendu sur navigateur et sur mobile, accessibilité au clavier, performances
- Envoi réel d'e-mails (confirmation, réinitialisation)

## Défauts trouvés et corrigés pendant cette phase
1. `middleware.ts` était à la racine alors que le projet utilise `src/` : Next.js l'aurait ignoré (routes privées non filtrées). Déplacé dans `src/middleware.ts`. *(Les données restaient protégées par la RLS.)*
2. Un test unitaire avait une attente erronée : corrigé.
3. `submit_attempt` (SQL) pouvait échouer sur une valeur non-UUID : conversion rendue sûre.
4. `tests/rls_tests.sql` supposait une base sans leçon publiée : rendu indépendant du contenu existant.

## Risques et limites restants
- **Sécurité non auditée** par un tiers. Les règles RLS n'ont jamais tourné sur une vraie base : lancez les tests SQL avant toute ouverture.
- Pas d'antivirus sur les fichiers téléversés ; type MIME fourni par le navigateur.
- Pas de limitation de débit sur la connexion, hors celle de Supabase Auth : vérifiez ses réglages.
- Pas de politique CSP (Content-Security-Policy) : à ajouter après essais.
- Questions ouvertes notées par mots-clés (approximatif).
- Le coût total de l'IA n'est pas plafonné par l'application (seulement par élève).
- Fonctionnement hors ligne : non implémenté.
- Programmes scolaires tchadiens : **aucun contenu officiel vérifié**. Classes et matières sont provisoires.
- Plus de 1000 élèves : le suivi admin (agrégation en mémoire) devra être réécrit.
- Phase 2 écrite (identité, accueil complet, confidentialité, pied de page, lien d'évitement, animations désactivées si réduction demandée) mais **jamais affichée dans un navigateur** : contrastes, rendu mobile et mise en page restent à vérifier visuellement.
- Le texte de confidentialité est un brouillon à faire relire (contact, durées de conservation, cadre légal tchadien).
