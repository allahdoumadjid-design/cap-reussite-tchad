import type { Config } from "tailwindcss";
const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      keyframes: { monte: { "0%": { opacity: "0", transform: "translateY(12px)" }, "100%": { opacity: "1", transform: "none" } } },
      animation: { monte: "monte .6s ease-out both" },
      colors: {
        marine: { 50: "#eef3fb", 600: "#1e4a8a", 800: "#0f2e5c", 900: "#0a2145" },
        action: { 500: "#f28c1b", 600: "#d97706" },
        succes: { 500: "#1f9d55", 600: "#177a42" },
      },
    },
  },
  plugins: [],
};
export default config;
