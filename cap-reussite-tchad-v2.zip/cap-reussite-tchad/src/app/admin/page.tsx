import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { requireAdmin } from "@/lib/auth";
import Entete from "@/components/Entete";

export default async function Admin() {
  const profil = await requireAdmin();
  const supabase = createClient();
  const { data: eleves } = await supabase.from("profiles").select("id, display_name, is_active, class_id").eq("role", "student").order("created_at", { ascending: false });
  const { data: classes } = await supabase.from("classes").select("id, name").order("sort_order");

  async function mettreAJour(f: FormData) {
    "use server";
    await requireAdmin(); // la RLS et le déclencheur SQL re-vérifient côté base
    const id = String(f.get("id")), classe = String(f.get("class_id") || "");
    await createClient().from("profiles").update({ is_active: f.get("is_active") === "on", class_id: classe || null }).eq("id", id);
    revalidatePath("/admin");
  }
  return (<><Entete profil={profil} />
    <main className="mx-auto max-w-5xl space-y-6 px-4 py-8">
      <h1 className="text-3xl font-bold text-marine-900">Gestion des élèves</h1>
      {(eleves ?? []).length === 0 && <p>Aucune inscription pour le moment.</p>}
      {(eleves ?? []).map((e: any) => (
        <form key={e.id} action={mettreAJour} className="flex flex-wrap items-center gap-4 rounded-lg border p-4">
          <input type="hidden" name="id" value={e.id} />
          <span className="min-w-40 font-medium">{e.display_name}</span>
          <label>Classe <select name="class_id" defaultValue={e.class_id ?? ""} className="rounded border px-2 py-1">
            <option value="">— aucune —</option>{(classes ?? []).map((c: any) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></label>
          <label><input type="checkbox" name="is_active" defaultChecked={e.is_active} /> Compte actif</label>
          <button className="rounded bg-marine-800 px-3 py-1.5 text-white">Enregistrer</button>
        </form>))}
    </main></>);
}
