import { notFound } from "next/navigation";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { requireProfil } from "@/lib/auth";
import Entete from "@/components/Entete";

// Contenu attendu : { "sections": [ { "titre": "...", "texte": "..." } ] }
export default async function Lecon({ params }: { params: { id: string } }) {
  const profil = await requireProfil();
  const supabase = createClient();
  const { data: lecon } = await supabase.from("lessons").select("id, title, content").eq("id", params.id).maybeSingle();
  if (!lecon) notFound();
  await supabase.from("student_progress").upsert(
    { student_id: profil.id, lesson_id: lecon.id, last_viewed_at: new Date().toISOString() },
    { onConflict: "student_id,lesson_id" });
  const { data: prog } = await supabase.from("student_progress").select("completed")
    .eq("student_id", profil.id).eq("lesson_id", lecon.id).maybeSingle();

  async function basculer() {
    "use server";
    const sb = createClient();
    const p = await requireProfil();
    await sb.from("student_progress").upsert(
      { student_id: p.id, lesson_id: params.id, completed: !prog?.completed }, { onConflict: "student_id,lesson_id" });
    revalidatePath(`/cours/${params.id}`);
  }
  const sections: { titre: string; texte: string }[] = lecon.content?.sections ?? [];
  return (<><Entete profil={profil} />
    <main className="mx-auto max-w-3xl space-y-6 px-4 py-8">
      <h1 className="text-3xl font-bold text-marine-900">{lecon.title}</h1>
      {sections.length === 0 && <p>Le contenu de cette leçon n'a pas encore été rédigé.</p>}
      {sections.map((s, i) => (<section key={i}><h2 className="text-xl font-semibold text-marine-800">{s.titre}</h2>
        <p className="mt-2 whitespace-pre-line leading-relaxed">{s.texte}</p></section>))}
      <form action={basculer}>
        <button className={"rounded px-4 py-2 font-semibold " + (prog?.completed ? "bg-slate-200" : "bg-succes-500 text-white")}>
          {prog?.completed ? "Marquer comme non terminée" : "Marquer comme terminée"}</button>
      </form>
    </main></>);
}
