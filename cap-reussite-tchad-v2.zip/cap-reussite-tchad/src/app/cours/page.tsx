import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { requireProfil } from "@/lib/auth";
import Entete from "@/components/Entete";

export default async function Catalogue() {
  const profil = await requireProfil();
  const supabase = createClient();
  const { data: matieres } = profil.class_id
    ? await supabase.from("subjects").select("id, name, chapters(id, title, sort_order, lessons(id, title, sort_order))")
        .eq("class_id", profil.class_id).order("sort_order")
    : { data: [] as any[] };
  const { data: faites } = await supabase.from("student_progress").select("lesson_id").eq("student_id", profil.id).eq("completed", true);
  const ok = new Set((faites ?? []).map((p: any) => p.lesson_id));
  return (<><Entete profil={profil} />
    <main className="mx-auto max-w-5xl space-y-6 px-4 py-8">
      <h1 className="text-3xl font-bold text-marine-900">Mes cours</h1>
      {!profil.is_active || !profil.class_id ? <p>Votre compte doit être activé et rattaché à une classe pour voir les cours.</p>
        : (matieres ?? []).length === 0 ? <p>Aucun cours publié pour votre classe pour le moment.</p>
        : (matieres ?? []).map((m: any) => (
          <section key={m.id} className="rounded-lg border p-5">
            <h2 className="text-xl font-semibold text-marine-800">{m.name}</h2>
            {(m.chapters ?? []).sort((a: any, b: any) => a.sort_order - b.sort_order).map((c: any) => (
              <div key={c.id} className="mt-3"><h3 className="font-medium">{c.title}</h3>
                <ul className="ml-4 list-disc">{(c.lessons ?? []).sort((a: any, b: any) => a.sort_order - b.sort_order).map((l: any) => (
                  <li key={l.id}><Link href={`/cours/${l.id}`} className="text-marine-600 underline">{l.title}</Link>{ok.has(l.id) && <span className="text-succes-600"> ✓ terminée</span>}</li>))}</ul>
              </div>))}
          </section>))}
    </main></>);
}
