"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export default function Connexion() {
  const router = useRouter();
  const [mode, setMode] = useState<"connexion" | "inscription">("connexion");
  const [message, setMessage] = useState<{ type: "erreur" | "ok"; texte: string } | null>(null);
  const [chargement, setChargement] = useState(false);

  async function envoyer(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setMessage(null); setChargement(true);
    const f = new FormData(e.currentTarget);
    const email = String(f.get("email")), password = String(f.get("password"));
    const supabase = createClient();
    if (mode === "connexion") {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) setMessage({ type: "erreur", texte: "E-mail ou mot de passe incorrect." });
      else { router.push("/tableau-de-bord"); router.refresh(); }
    } else {
      const { error } = await supabase.auth.signUp({
        email, password, options: { data: { display_name: String(f.get("nom")) } },
      });
      if (error) setMessage({ type: "erreur", texte: "Inscription impossible : " + error.message });
      else setMessage({ type: "ok", texte: "Demande envoyée. Un administrateur doit activer votre compte avant votre première connexion complète." });
    }
    setChargement(false);
  }

  const champ = "w-full rounded border border-slate-400 px-3 py-2";
  return (
    <main className="mx-auto max-w-md px-6 py-16">
      <h1 className="mb-6 text-2xl font-bold text-marine-900">{mode === "connexion" ? "Se connecter" : "Demander un accès"}</h1>
      <form onSubmit={envoyer} className="space-y-4">
        {mode === "inscription" && (
          <div><label htmlFor="nom" className="mb-1 block font-medium">Nom complet</label>
            <input id="nom" name="nom" required minLength={2} maxLength={80} className={champ} /></div>
        )}
        <div><label htmlFor="email" className="mb-1 block font-medium">Adresse e-mail</label>
          <input id="email" name="email" type="email" required autoComplete="email" className={champ} /></div>
        <div><label htmlFor="password" className="mb-1 block font-medium">Mot de passe (8 caractères minimum)</label>
          <input id="password" name="password" type="password" required minLength={8}
            autoComplete={mode === "connexion" ? "current-password" : "new-password"} className={champ} /></div>
        {message && <p role="alert" className={message.type === "erreur" ? "text-red-700" : "text-succes-600"}>{message.texte}</p>}
        <button disabled={chargement} className="w-full rounded bg-action-500 px-4 py-2 font-semibold text-marine-900 disabled:opacity-60">
          {chargement ? "Veuillez patienter…" : mode === "connexion" ? "Se connecter" : "Envoyer la demande"}
        </button>
      </form>
      <button onClick={() => { setMode(mode === "connexion" ? "inscription" : "connexion"); setMessage(null); }}
        className="mt-6 text-marine-600 underline">
        {mode === "connexion" ? "Pas encore de compte ? Demander un accès" : "J'ai déjà un compte"}
      </button>
    </main>
  );
}
