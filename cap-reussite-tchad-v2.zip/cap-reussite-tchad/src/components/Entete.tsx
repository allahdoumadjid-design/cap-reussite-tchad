import Link from "next/link";
import type { Profil } from "@/lib/auth";

export default function Entete({ profil }: { profil: Profil }) {
  return (
    <header className="bg-marine-900 text-white">
      <nav aria-label="Navigation principale" className="mx-auto flex max-w-5xl flex-wrap items-center gap-4 px-4 py-3">
        <Link href="/tableau-de-bord" className="font-bold">CAP RÉUSSITE TCHAD</Link>
        <Link href="/cours" className="hover:underline">Cours</Link>
        {profil.role === "admin" && <Link href="/admin" className="hover:underline">Administration</Link>}
        <form action="/deconnexion" method="post" className="ml-auto">
          <button className="rounded bg-action-500 px-3 py-1.5 font-semibold text-marine-900">Se déconnecter</button>
        </form>
      </nav>
    </header>
  );
}
